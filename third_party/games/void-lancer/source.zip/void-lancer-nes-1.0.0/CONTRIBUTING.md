# Contributing

Contributions are welcome.

## Ground rules

- Keep the game compatible with the documented mapper-0 target unless a mapper change is explicitly discussed first.
- Do not submit ripped commercial graphics, music, maps, code, or trademarks.
- Prefer changes that can be reproduced from source by `python3 tools/build.py`.
- Run `python3 tools/smoke_test.py` before opening a pull request.
- If changing CHR or nametable generation, regenerate the screenshots when useful.

## Suggested workflow

```bash
git clone <repo>
cd void-lancer-nes
python3 tools/build.py
python3 tools/smoke_test.py
```

For gameplay changes, test the resulting `build/void-lancer.nes` in an accurate NES emulator as well.
