; VOID LANCER - original open-source NES vertical shooter
; Mapper 0 / NROM-256, 32 KiB PRG + 8 KiB CHR, NTSC timing.
; Built by tools/build.py using the tiny dependency-free assembler.

; --- Hardware registers -----------------------------------------------------
PPUCTRL     = $2000
PPUMASK     = $2001
PPUSTATUS   = $2002
OAMADDR     = $2003
PPUSCROLL   = $2005
PPUADDR     = $2006
PPUDATA     = $2007
OAMDMA      = $4014
APUSTATUS   = $4015
JOY1        = $4016
APUFRAME    = $4017

; --- Controller bits after read_pad ----------------------------------------
PAD_A       = $80
PAD_B       = $40
PAD_SELECT  = $20
PAD_START   = $10
PAD_UP      = $08
PAD_DOWN    = $04
PAD_LEFT    = $02
PAD_RIGHT   = $01

; --- Zero page --------------------------------------------------------------
state       = $00        ; 0 title, 1 game, 2 game over, 3 win
pad         = $01
pad_prev    = $02
pad_pressed = $03
frame       = $04
scroll_y    = $05
player_x    = $06
player_y    = $07
shot_cd     = $08
weapon      = $09
lives       = $0A
bombs       = $0B
invuln      = $0C
stage       = $0D
stage_lo    = $0E
stage_hi    = $0F
spawn_cd    = $10
spawn_index = $11
threat      = $12
kill_count  = $13
music_div   = $14
music_step  = $15
music_mode  = $16        ; 0 title/end, 1 stage1, 2 stage2, 3 stage3/core, 4 boss, 5 win
sfx_timer   = $17
sfx_type    = $18
bg_ptr_lo   = $19
bg_ptr_hi   = $1A
tmp0        = $1B
tmp1        = $1C
tmp2        = $1D
boss_active = $1E
boss_hp     = $1F
end_timer   = $20
nmi_count   = $21
bomb_flash  = $22
power_active= $23
power_x     = $24
power_y     = $25
shots_meter = $26
noise_timer = $27
sprite_x    = $28
sprite_y    = $29
sprite_tile = $2A
sprite_attr = $2B
oam_index   = $2C

; Audio v2 persistent state (free ZP)
music_lead_ctl = $36
music_harm_ctl = $37
music_lead_on  = $38
music_harm_on  = $39
music_lead_note= $3A
music_harm_note= $3B

score0      = $30        ; six decimal digits, most significant first
score1      = $31
score2      = $32
score3      = $33
score4      = $34
score5      = $35

; --- RAM arrays -------------------------------------------------------------
OAM         = $0200
EN_TYPE     = $0300      ; storage for 8, 6 active regular-enemy slots + boss
EN_X        = $0308
EN_Y        = $0310
EN_DX       = $0318
EN_HP       = $0320
EN_TIMER    = $0328
PB_X        = $0340      ; player bullets, inactive when Y=$FF
PB_Y        = $0348
PB_DX       = $0350
EB_X        = $0360      ; enemy bullets, inactive when Y=$FF
EB_Y        = $0368
EB_DX       = $0370

; --- Sprite tile numbers (pattern table $1000) -----------------------------
ENEMY_SLOTS   = 6         ; 16x16 regular enemies: keeps OAM below 64 sprites
SPR_PLAYER_TL = 0
SPR_PLAYER_TR = 1
SPR_PLAYER_BL = 2
SPR_PLAYER_BR = 3
SPR_PBULLET   = 4
SPR_SCOUT     = 5
SPR_GUNNER    = 6
SPR_EBULLET   = 7
SPR_POWER     = 8
SPR_SEEKER    = 9
SPR_EXPLODE1  = 10
SPR_EXPLODE2  = 11
SPR_BOMB      = 12
SPR_THRUST_A  = 13
SPR_THRUST_B  = 14
SPR_BOSS_0    = 16        ; 32x24 boss uses 16..27, row-major
SPR_LIFE      = 74
SPR_WEAPON1   = 75        ; 75..77 = weapon level 1..3
SPR_STAGE1    = 78        ; 78..80 = stage badges
SPR_SCOUT_ALT = 40
SPR_GUNNER_ALT= 41
SPR_SEEKER_ALT= 42
SPR_THREAT0   = 48        ; 48..55 = threat gauge 0..7
SPR_DIGIT0    = 64
SPR_EBULLET_S1 = 43
SPR_EBULLET_S2 = 44
SPR_EBULLET_S3 = 45
SPR_EBULLET_BA = 46
SPR_EBULLET_BB = 47
SPR_POWER_A    = 56        ; 56..59 animated crystal
SPR_PBULLET_1  = 60
SPR_PBULLET_2  = 61
SPR_PBULLET_3  = 62
SPR_PBULLET_3B = 63
SPR_ENEMY_S1   = 96        ; 96..119, three 16x16 types x two frames
SPR_ENEMY_S2   = 120       ; 120..143
SPR_ENEMY_S3   = 144       ; 144..167
SPR_EXP16      = 168       ; 168..191, six 16x16 explosion frames

.org $8000

; ============================================================================
; RESET / INTERRUPTS
; ============================================================================
reset:
    sei
    cld
    ldx #$40
    stx APUFRAME
    ldx #$FF
    txs
    inx
    stx PPUCTRL
    stx PPUMASK
    stx APUSTATUS

    bit PPUSTATUS
reset_wait_vblank_1:
    bit PPUSTATUS
    bpl reset_wait_vblank_1
reset_wait_vblank_2:
    bit PPUSTATUS
    bpl reset_wait_vblank_2

    lda #0
    ldx #0
reset_clear_zp:
    sta $0000,x
    inx
    bne reset_clear_zp

    lda #$FF
    ldx #0
reset_clear_bullets:
    sta PB_Y,x
    sta EB_Y,x
    inx
    cpx #8
    bne reset_clear_bullets

    jsr clear_oam
    jsr apu_init

    lda #<title_nam
    sta bg_ptr_lo
    lda #>title_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_title
    sta bg_ptr_lo
    lda #>palette_title
    sta bg_ptr_hi
    jsr load_palette_ptr
    jsr reset_scroll_latch

    lda #0
    sta state
    sta scroll_y
    sta music_step
    sta music_div
    sta music_mode
    lda #$88                ; NMI on, sprites $1000, BG $0000
    sta PPUCTRL
    lda #$1E
    sta PPUMASK

main_loop:
    jsr wait_frame
    inc frame
    jsr read_pad
    jsr music_tick

    lda state
    beq update_title
    cmp #1
    beq update_game
    jmp update_end

nmi:
    pha
    txa
    pha
    tya
    pha

    lda #0
    sta OAMADDR
    lda #$02
    sta OAMDMA

    bit PPUSTATUS
    lda #0
    sta PPUSCROLL
    lda state
    cmp #1
    bne nmi_no_game_scroll
    lda scroll_y
    jmp nmi_write_y
nmi_no_game_scroll:
    lda #0
nmi_write_y:
    sta PPUSCROLL
    lda #$88
    sta PPUCTRL

    inc nmi_count
    pla
    tay
    pla
    tax
    pla
    rti

irq:
    rti

wait_frame:
    lda nmi_count
wait_frame_loop:
    cmp nmi_count
    beq wait_frame_loop
    rts

; ============================================================================
; INPUT
; ============================================================================
read_pad:
    lda #1
    sta JOY1
    lda #0
    sta JOY1
    ldx #8
    lda #0
    sta pad
read_pad_loop:
    lda JOY1
    lsr A
    rol pad
    dex
    bne read_pad_loop

    lda pad_prev
    eor #$FF
    and pad
    sta pad_pressed
    lda pad
    sta pad_prev
    rts

; ============================================================================
; SCREEN / PPU
; ============================================================================
screen_load_begin:
    jsr wait_frame
    lda #$08                ; keep sprite pattern selection, disable NMI
    sta PPUCTRL
    lda #0
    sta PPUMASK
    rts

screen_load_end:
    jsr reset_scroll_latch
    lda #$88
    sta PPUCTRL
    lda #$1E
    sta PPUMASK
    rts

reset_scroll_latch:
    bit PPUSTATUS
    lda #0
    sta PPUSCROLL
    sta PPUSCROLL
    rts

load_nametable_ptr:
    bit PPUSTATUS
    lda #$20
    sta PPUADDR
    lda #$00
    sta PPUADDR
    ldx #4
    ldy #0
load_nametable_page:
    lda (bg_ptr_lo),y
    sta PPUDATA
    iny
    bne load_nametable_page
    inc bg_ptr_hi
    dex
    bne load_nametable_page
    rts

load_palette_ptr:
    bit PPUSTATUS
    lda #$3F
    sta PPUADDR
    lda #$00
    sta PPUADDR
    ldy #0
load_palette_loop:
    lda (bg_ptr_lo),y
    sta PPUDATA
    iny
    cpy #32
    bne load_palette_loop
    rts

load_title_screen:
    jsr screen_load_begin
    lda #<title_nam
    sta bg_ptr_lo
    lda #>title_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_title
    sta bg_ptr_lo
    lda #>palette_title
    sta bg_ptr_hi
    jsr load_palette_ptr
    lda #0
    sta scroll_y
    jsr screen_load_end
    rts

load_stage_screen:
    jsr screen_load_begin
    lda stage
    cmp #1
    beq load_stage_one
    cmp #2
    beq load_stage_two

load_stage_three:
    lda #<stage3_nam
    sta bg_ptr_lo
    lda #>stage3_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_stage3
    sta bg_ptr_lo
    lda #>palette_stage3
    sta bg_ptr_hi
    jmp load_stage_finish

load_stage_two:
    lda #<stage2_nam
    sta bg_ptr_lo
    lda #>stage2_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_stage2
    sta bg_ptr_lo
    lda #>palette_stage2
    sta bg_ptr_hi
    jmp load_stage_finish

load_stage_one:
    lda #<stage1_nam
    sta bg_ptr_lo
    lda #>stage1_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_stage1
    sta bg_ptr_lo
    lda #>palette_stage1
    sta bg_ptr_hi

load_stage_finish:
    jsr load_palette_ptr
    lda #0
    sta scroll_y
    jsr screen_load_end
    rts

load_gameover_screen:
    jsr screen_load_begin
    lda #<gameover_nam
    sta bg_ptr_lo
    lda #>gameover_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_title
    sta bg_ptr_lo
    lda #>palette_title
    sta bg_ptr_hi
    jsr load_palette_ptr
    jsr screen_load_end
    rts

load_win_screen:
    jsr screen_load_begin
    lda #<win_nam
    sta bg_ptr_lo
    lda #>win_nam
    sta bg_ptr_hi
    jsr load_nametable_ptr
    lda #<palette_win
    sta bg_ptr_lo
    lda #>palette_win
    sta bg_ptr_hi
    jsr load_palette_ptr
    jsr screen_load_end
    rts

; ============================================================================
; TITLE / END STATES
; ============================================================================
update_title:
    jsr clear_oam
    lda pad_pressed
    and #PAD_START
    beq update_title_done
    jsr sfx_start
    jsr start_game
update_title_done:
    jmp main_loop

update_end:
    jsr build_end_oam
    lda pad_pressed
    and #PAD_START
    beq update_end_done
    jsr sfx_start
    jsr enter_title
update_end_done:
    jmp main_loop

enter_title:
    lda #0
    sta state
    sta music_mode
    sta music_step
    sta music_div
    jsr load_title_screen
    jsr clear_oam
    rts

enter_gameover:
    lda #2
    sta state
    lda #0
    sta music_mode
    sta music_step
    jsr build_end_oam
    jsr load_gameover_screen
    jsr sfx_explosion
    rts

enter_win:
    lda #3
    sta state
    lda #0
    sta music_step
    lda #5
    sta music_mode
    lda #0
    sta music_div
    jsr build_end_oam
    jsr load_win_screen
    jsr sfx_start
    rts

; ============================================================================
; GAME STATE
; ============================================================================
start_game:
    lda #0
    sta score0
    sta score1
    sta score2
    sta score3
    sta score4
    sta score5
    sta weapon
    sta threat
    sta kill_count
    sta stage_lo
    sta stage_hi
    sta spawn_index
    sta boss_active
    sta power_active
    sta shots_meter
    sta invuln
    sta music_step
    sta music_div
    lda #3
    sta lives
    sta bombs
    lda #1
    sta stage
    sta music_mode
    lda #120
    sta player_x
    lda #200
    sta player_y
    lda #20
    sta spawn_cd
    jsr clear_game_objects
    lda #1
    sta state
    jsr load_stage_screen
    jsr build_game_oam
    rts

clear_game_objects:
    lda #0
    ldx #0
clear_game_enemy_loop:
    sta EN_TYPE,x
    sta EN_HP,x
    sta EN_TIMER,x
    inx
    cpx #8
    bne clear_game_enemy_loop
    lda #$FF
    ldx #0
clear_game_bullet_loop:
    sta PB_Y,x
    sta EB_Y,x
    inx
    cpx #8
    bne clear_game_bullet_loop
    lda #0
    sta power_active
    rts

update_game:
    jsr update_player
    jsr update_player_bullets
    jsr update_enemy_spawning
    jsr update_enemies
    jsr update_enemy_bullets
    jsr update_powerup
    jsr collide_player_bullets
    lda state
    cmp #1
    bne update_game_state_changed
    jsr collide_player
    lda state
    cmp #1
    bne update_game_state_changed
    jsr update_stage_clock
    lda state
    cmp #1
    bne update_game_state_changed
    jsr update_scroll
    jsr build_game_oam
update_game_state_changed:
    jmp main_loop

update_scroll:
    lda frame
    and #1
    bne update_scroll_done
    inc scroll_y
    lda scroll_y
    cmp #240
    bcc update_scroll_done
    lda #0
    sta scroll_y
update_scroll_done:
    rts

; ============================================================================
; PLAYER
; ============================================================================
update_player:
    lda invuln
    beq player_no_invuln_tick
    dec invuln
player_no_invuln_tick:
    lda shot_cd
    beq player_no_shot_cd
    dec shot_cd
player_no_shot_cd:

    lda pad
    and #PAD_LEFT
    beq player_no_left
    lda player_x
    cmp #8
    bcc player_no_left
    beq player_no_left
    sec
    sbc #2
    sta player_x
player_no_left:
    lda pad
    and #PAD_RIGHT
    beq player_no_right
    lda player_x
    cmp #232
    bcs player_no_right
    clc
    adc #2
    sta player_x
player_no_right:
    lda pad
    and #PAD_UP
    beq player_no_up
    lda player_y
    cmp #40
    bcc player_no_up
    beq player_no_up
    sec
    sbc #2
    sta player_y
player_no_up:
    lda pad
    and #PAD_DOWN
    beq player_no_down
    lda player_y
    cmp #216
    bcs player_no_down
    clc
    adc #2
    sta player_y
player_no_down:

    lda pad
    and #PAD_A
    beq player_no_fire
    lda shot_cd
    bne player_no_fire
    jsr fire_player
player_no_fire:

    lda pad_pressed
    and #PAD_B
    beq player_no_bomb
    lda bombs
    beq player_no_bomb
    jsr use_bomb
player_no_bomb:
    rts

fire_player:
    inc shots_meter
    lda shots_meter
    cmp #16
    bcc fire_player_threat_done
    lda #0
    sta shots_meter
    lda threat
    cmp #7
    bcs fire_player_threat_done
    inc threat
fire_player_threat_done:

    lda player_y
    sec
    sbc #4
    sta tmp1

    lda weapon
    beq fire_level0
    cmp #1
    beq fire_level1

fire_level2:
    lda player_x
    clc
    adc #4
    sta tmp0
    lda #0
    sta tmp2
    jsr spawn_player_bullet
    lda player_x
    sta tmp0
    lda #$FF
    sta tmp2
    jsr spawn_player_bullet
    lda player_x
    clc
    adc #8
    sta tmp0
    lda #1
    sta tmp2
    jsr spawn_player_bullet
    lda #5
    sta shot_cd
    jmp fire_player_sound

fire_level1:
    lda player_x
    clc
    adc #1
    sta tmp0
    lda #0
    sta tmp2
    jsr spawn_player_bullet
    lda player_x
    clc
    adc #9
    sta tmp0
    lda #0
    sta tmp2
    jsr spawn_player_bullet
    lda #6
    sta shot_cd
    jmp fire_player_sound

fire_level0:
    lda player_x
    clc
    adc #4
    sta tmp0
    lda #0
    sta tmp2
    jsr spawn_player_bullet
    lda #7
    sta shot_cd

fire_player_sound:
    jsr sfx_shot
    rts

spawn_player_bullet:
    ldy #0
spawn_player_bullet_find:
    lda PB_Y,y
    cmp #$FF
    beq spawn_player_bullet_found
    iny
    cpy #8
    bne spawn_player_bullet_find
    rts
spawn_player_bullet_found:
    lda tmp0
    sta PB_X,y
    lda tmp1
    sta PB_Y,y
    lda tmp2
    sta PB_DX,y
    rts

update_player_bullets:
    ldx #0
update_pb_loop:
    lda PB_Y,x
    cmp #$FF
    beq update_pb_next
    sec
    sbc #4
    bcc update_pb_kill
    cmp #8
    bcc update_pb_kill
    sta PB_Y,x
    lda PB_X,x
    clc
    adc PB_DX,x
    sta PB_X,x
    cmp #4
    bcc update_pb_kill
    cmp #248
    bcs update_pb_kill
    jmp update_pb_next
update_pb_kill:
    lda #$FF
    sta PB_Y,x
update_pb_next:
    inx
    cpx #8
    bne update_pb_loop
    rts

use_bomb:
    dec bombs
    lda #10
    sta bomb_flash
    ldx #0
use_bomb_clear_bullets:
    lda #$FF
    sta EB_Y,x
    inx
    cpx #8
    bne use_bomb_clear_bullets

    ldx #0
use_bomb_enemies:
    lda EN_TYPE,x
    beq use_bomb_next_enemy
    cmp #4
    beq use_bomb_boss
    lda #0
    sta EN_TYPE,x
    jsr score_add_100
    jmp use_bomb_next_enemy
use_bomb_boss:
    lda EN_HP,x
    cmp #6
    bcc use_bomb_boss_low
    sec
    sbc #5
    sta EN_HP,x
    jmp use_bomb_next_enemy
use_bomb_boss_low:
    lda #1
    sta EN_HP,x
use_bomb_next_enemy:
    inx
    cpx #ENEMY_SLOTS
    bne use_bomb_enemies
    jsr sfx_bomb
    rts

player_hit:
    lda invuln
    bne player_hit_done
    lda lives
    beq player_hit_done
    dec lives
    lda lives
    beq player_hit_gameover
    lda #120
    sta invuln
    lda #120
    sta player_x
    lda #200
    sta player_y
    lda weapon
    beq player_hit_no_weapon_loss
    dec weapon
player_hit_no_weapon_loss:
    lda threat
    cmp #2
    bcc player_hit_zero_threat
    sec
    sbc #2
    sta threat
    jmp player_hit_sound
player_hit_zero_threat:
    lda #0
    sta threat
player_hit_sound:
    jsr sfx_explosion
    rts
player_hit_gameover:
    jsr enter_gameover
player_hit_done:
    rts

; ============================================================================
; ENEMIES / THREAT SYSTEM
; ============================================================================
update_enemy_spawning:
    lda stage
    cmp #3
    bne enemy_spawn_not_boss_stage
    lda boss_active
    bne enemy_spawn_done
enemy_spawn_not_boss_stage:
    lda spawn_cd
    beq enemy_spawn_now
    dec spawn_cd
    rts
enemy_spawn_now:
    jsr spawn_enemy
    lda threat
    asl A
    sta tmp0
    lda stage
    cmp #1
    beq enemy_spawn_interval_1
    cmp #2
    beq enemy_spawn_interval_2
    lda #34
    jmp enemy_spawn_interval_sub
enemy_spawn_interval_2:
    lda #40
    jmp enemy_spawn_interval_sub
enemy_spawn_interval_1:
    lda #48
enemy_spawn_interval_sub:
    sec
    sbc tmp0
    sta spawn_cd
enemy_spawn_done:
    rts

spawn_enemy:
    ldx #0
spawn_enemy_find:
    lda EN_TYPE,x
    beq spawn_enemy_found
    inx
    cpx #ENEMY_SLOTS
    bne spawn_enemy_find
    rts
spawn_enemy_found:
    lda spawn_index
    and #$0F
    tay
    lda spawn_x_table,y
    sta EN_X,x
    lda #24
    sta EN_Y,x
    lda spawn_index
    and #1
    beq spawn_enemy_dx_right
    lda #$FF
    jmp spawn_enemy_dx_set
spawn_enemy_dx_right:
    lda #1
spawn_enemy_dx_set:
    sta EN_DX,x
    lda spawn_index
    asl A
    asl A
    asl A
    sta EN_TIMER,x

    lda stage
    cmp #1
    beq spawn_enemy_stage1
    cmp #2
    beq spawn_enemy_stage2

spawn_enemy_stage3:
    lda spawn_index
    and #3
    beq spawn_enemy_make_gunner
    lda #3
    sta EN_TYPE,x
    lda #2
    sta EN_HP,x
    jmp spawn_enemy_finish

spawn_enemy_stage2:
    lda spawn_index
    and #3
    beq spawn_enemy_make_seeker
    lda #2
    sta EN_TYPE,x
    lda #2
    sta EN_HP,x
    jmp spawn_enemy_finish

spawn_enemy_stage1:
    lda spawn_index
    and #3
    beq spawn_enemy_make_gunner
    lda #1
    sta EN_TYPE,x
    lda #1
    sta EN_HP,x
    jmp spawn_enemy_finish

spawn_enemy_make_gunner:
    lda #2
    sta EN_TYPE,x
    lda #2
    sta EN_HP,x
    jmp spawn_enemy_finish
spawn_enemy_make_seeker:
    lda #3
    sta EN_TYPE,x
    lda #2
    sta EN_HP,x
spawn_enemy_finish:
    inc spawn_index
    rts

update_enemies:
    ldx #0
update_enemy_loop:
    lda EN_TYPE,x
    beq update_enemy_next
    cmp #4
    beq update_enemy_boss

    inc EN_TIMER,x
    lda EN_TYPE,x
    cmp #2
    beq update_enemy_y_fast
    lda EN_Y,x
    clc
    adc #1
    sta EN_Y,x
    jmp update_enemy_move_x
update_enemy_y_fast:
    lda EN_Y,x
    clc
    adc #2
    sta EN_Y,x

update_enemy_move_x:
    lda EN_X,x
    clc
    adc EN_DX,x
    sta EN_X,x
    cmp #10
    bcc update_enemy_bounce_right
    cmp #238
    bcs update_enemy_bounce_left
    jmp update_enemy_check_bottom
update_enemy_bounce_right:
    lda #1
    sta EN_DX,x
    jmp update_enemy_check_bottom
update_enemy_bounce_left:
    lda #$FF
    sta EN_DX,x

update_enemy_check_bottom:
    lda EN_Y,x
    cmp #224
    bcc update_enemy_fire_check
    lda #0
    sta EN_TYPE,x
    jmp update_enemy_next

update_enemy_fire_check:
    lda EN_TYPE,x
    cmp #2
    beq update_enemy_gunner_fire
    cmp #3
    beq update_enemy_seeker_fire
    jmp update_enemy_next
update_enemy_gunner_fire:
    lda EN_TIMER,x
    and #$3F
    bne update_enemy_next
    lda EN_X,x
    clc
    adc #2
    sta tmp0
    lda EN_Y,x
    clc
    adc #8
    sta tmp1
    lda #0
    sta tmp2
    jsr spawn_enemy_bullet
    jmp update_enemy_next
update_enemy_seeker_fire:
    lda EN_TIMER,x
    and #$1F
    bne update_enemy_next
    lda EN_X,x
    clc
    adc #2
    sta tmp0
    lda EN_Y,x
    clc
    adc #8
    sta tmp1
    lda player_x
    cmp EN_X,x
    bcc update_enemy_aim_left
    lda #1
    jmp update_enemy_aim_set
update_enemy_aim_left:
    lda #$FF
update_enemy_aim_set:
    sta tmp2
    jsr spawn_enemy_bullet
    jmp update_enemy_next

update_enemy_boss:
    inc EN_TIMER,x
    lda EN_X,x
    clc
    adc EN_DX,x
    sta EN_X,x
    cmp #48
    bcc update_boss_right
    cmp #192
    bcs update_boss_left
    jmp update_boss_fire
update_boss_right:
    lda #1
    sta EN_DX,x
    jmp update_boss_fire
update_boss_left:
    lda #$FF
    sta EN_DX,x
update_boss_fire:
    lda EN_TIMER,x
    and #$0F
    bne update_enemy_next
    lda EN_X,x
    clc
    adc #4
    sta tmp0
    lda EN_Y,x
    clc
    adc #16
    sta tmp1
    lda #$FF
    sta tmp2
    jsr spawn_enemy_bullet
    lda EN_X,x
    clc
    adc #8
    sta tmp0
    lda #0
    sta tmp2
    jsr spawn_enemy_bullet
    lda EN_X,x
    clc
    adc #12
    sta tmp0
    lda #1
    sta tmp2
    jsr spawn_enemy_bullet

update_enemy_next:
    inx
    cpx #ENEMY_SLOTS
    bne update_enemy_loop
    rts

spawn_enemy_bullet:
    ldy #0
spawn_enemy_bullet_find:
    lda EB_Y,y
    cmp #$FF
    beq spawn_enemy_bullet_found
    iny
    cpy #8
    bne spawn_enemy_bullet_find
    rts
spawn_enemy_bullet_found:
    lda tmp0
    sta EB_X,y
    lda tmp1
    sta EB_Y,y
    lda tmp2
    sta EB_DX,y
    rts

update_enemy_bullets:
    ldx #0
update_eb_loop:
    lda EB_Y,x
    cmp #$FF
    beq update_eb_next
    clc
    adc #2
    sta EB_Y,x
    cmp #232
    bcs update_eb_kill
    lda EB_X,x
    clc
    adc EB_DX,x
    sta EB_X,x
    cmp #3
    bcc update_eb_kill
    cmp #250
    bcs update_eb_kill
    jmp update_eb_next
update_eb_kill:
    lda #$FF
    sta EB_Y,x
update_eb_next:
    inx
    cpx #8
    bne update_eb_loop
    rts

spawn_boss:
    jsr clear_game_objects
    lda #4
    sta EN_TYPE
    lda #112
    sta EN_X
    lda #48
    sta EN_Y
    lda #1
    sta EN_DX
    lda #40
    sta EN_HP
    sta boss_hp
    lda #0
    sta EN_TIMER
    lda #1
    sta boss_active
    lda #4
    sta music_mode
    lda #0
    sta music_step
    sta music_div
    jsr sfx_start
    rts

; ============================================================================
; POWERUP
; ============================================================================
update_powerup:
    lda power_active
    beq update_power_done
    inc power_y
    lda power_y
    cmp #224
    bcc update_power_collision
    lda #0
    sta power_active
    rts
update_power_collision:
    lda power_x
    clc
    adc #4
    cmp player_x
    bcc update_power_done
    lda player_x
    clc
    adc #16
    cmp power_x
    bcc update_power_done
    lda power_y
    clc
    adc #4
    cmp player_y
    bcc update_power_done
    lda player_y
    clc
    adc #16
    cmp power_y
    bcc update_power_done
    lda #0
    sta power_active
    lda weapon
    cmp #2
    bcs update_power_threat
    inc weapon
update_power_threat:
    lda threat
    cmp #7
    bcs update_power_sound
    inc threat
update_power_sound:
    jsr sfx_power
update_power_done:
    rts

; ============================================================================
; COLLISION
; ============================================================================
collide_player_bullets:
    ldx #0
collide_pb_outer:
    lda PB_Y,x
    cmp #$FF
    beq collide_pb_next
    ldy #0
collide_pb_inner:
    lda EN_TYPE,y
    beq collide_pb_no_hit
    cmp #4
    beq collide_pb_boss_size
    lda #16                ; regular enemies are now 16x16
    jmp collide_pb_size_set
collide_pb_boss_size:
    lda #32
collide_pb_size_set:
    sta tmp2

    lda PB_X,x
    clc
    adc #4
    cmp EN_X,y
    bcc collide_pb_no_hit
    lda EN_X,y
    clc
    adc tmp2
    cmp PB_X,x
    bcc collide_pb_no_hit
    lda PB_Y,x
    clc
    adc #4
    cmp EN_Y,y
    bcc collide_pb_no_hit
    lda EN_Y,y
    clc
    adc tmp2
    cmp PB_Y,x
    bcc collide_pb_no_hit

    lda #$FF
    sta PB_Y,x
    lda EN_HP,y
    sec
    sbc #1
    sta EN_HP,y
    bne collide_pb_bullet_done

    lda EN_TYPE,y
    cmp #4
    beq collide_pb_kill_boss
    lda #0
    sta EN_TYPE,y
    jsr score_add_100
    inc kill_count
    lda power_active
    bne collide_pb_no_drop
    lda kill_count
    and #7
    bne collide_pb_no_drop
    lda #1
    sta power_active
    lda EN_X,y
    sta power_x
    lda EN_Y,y
    sta power_y
collide_pb_no_drop:
    lda kill_count
    and #3
    bne collide_pb_threat_done
    lda threat
    cmp #7
    bcs collide_pb_threat_done
    inc threat
collide_pb_threat_done:
    jsr sfx_hit
    jmp collide_pb_bullet_done

collide_pb_kill_boss:
    lda #0
    sta EN_TYPE,y
    sta boss_active
    jsr score_add_1000
    jsr enter_win
    rts

collide_pb_no_hit:
    iny
    cpy #ENEMY_SLOTS
    bne collide_pb_inner
collide_pb_bullet_done:
collide_pb_next:
    inx
    cpx #8
    bne collide_pb_outer
    rts

collide_player:
    lda invuln
    bne collide_player_done

    ldx #0
collide_player_eb_loop:
    lda EB_Y,x
    cmp #$FF
    beq collide_player_eb_next
    lda EB_X,x
    clc
    adc #4
    cmp player_x
    bcc collide_player_eb_next
    lda player_x
    clc
    adc #16
    cmp EB_X,x
    bcc collide_player_eb_next
    lda EB_Y,x
    clc
    adc #4
    cmp player_y
    bcc collide_player_eb_next
    lda player_y
    clc
    adc #16
    cmp EB_Y,x
    bcc collide_player_eb_next
    lda #$FF
    sta EB_Y,x
    jsr player_hit
    rts
collide_player_eb_next:
    inx
    cpx #8
    bne collide_player_eb_loop

    ldx #0
collide_player_enemy_loop:
    lda EN_TYPE,x
    beq collide_player_enemy_next
    cmp #4
    beq collide_player_enemy_next
    lda EN_X,x
    clc
    adc #14                ; forgiving 16x16 visual hitbox
    cmp player_x
    bcc collide_player_enemy_next
    lda player_x
    clc
    adc #16
    cmp EN_X,x
    bcc collide_player_enemy_next
    lda EN_Y,x
    clc
    adc #14
    cmp player_y
    bcc collide_player_enemy_next
    lda player_y
    clc
    adc #16
    cmp EN_Y,x
    bcc collide_player_enemy_next
    lda #0
    sta EN_TYPE,x
    jsr player_hit
    rts
collide_player_enemy_next:
    inx
    cpx #ENEMY_SLOTS
    bne collide_player_enemy_loop
collide_player_done:
    rts

; ============================================================================
; STAGES
; ============================================================================
update_stage_clock:
    inc stage_lo
    bne stage_clock_no_carry
    inc stage_hi
stage_clock_no_carry:
    lda stage
    cmp #1
    beq stage_clock_one
    cmp #2
    beq stage_clock_two

stage_clock_three:
    lda boss_active
    bne stage_clock_done
    lda stage_hi
    cmp #2
    bcc stage_clock_done
    jsr spawn_boss
    jmp stage_clock_done

stage_clock_one:
    lda stage_hi
    cmp #4
    bcc stage_clock_done
    lda #2
    sta stage
    sta music_mode
    lda #0
    sta music_step
    sta music_div
    jsr transition_stage
    jmp stage_clock_done

stage_clock_two:
    lda stage_hi
    cmp #4
    bcc stage_clock_done
    lda #3
    sta stage
    sta music_mode
    lda #0
    sta music_step
    sta music_div
    jsr transition_stage
stage_clock_done:
    rts

transition_stage:
    lda #0
    sta stage_lo
    sta stage_hi
    sta spawn_index
    sta boss_active
    lda #24
    sta spawn_cd
    jsr clear_game_objects
    jsr load_stage_screen
    jsr sfx_start
    rts

; ============================================================================
; SCORE
; ============================================================================
score_add_100:
    inc score3
    lda score3
    cmp #10
    bcc score_add_100_done
    lda #0
    sta score3
    inc score2
    lda score2
    cmp #10
    bcc score_add_100_done
    lda #0
    sta score2
    inc score1
    lda score1
    cmp #10
    bcc score_add_100_done
    lda #0
    sta score1
    inc score0
    lda score0
    cmp #10
    bcc score_add_100_done
    lda #9
    sta score0
score_add_100_done:
    rts

score_add_1000:
    inc score2
    lda score2
    cmp #10
    bcc score_add_1000_done
    lda #0
    sta score2
    inc score1
    lda score1
    cmp #10
    bcc score_add_1000_done
    lda #0
    sta score1
    inc score0
    lda score0
    cmp #10
    bcc score_add_1000_done
    lda #9
    sta score0
score_add_1000_done:
    rts

; ============================================================================
; OAM / DRAWING
; ============================================================================
clear_oam:
    lda #$F8
    ldx #0
clear_oam_loop:
    sta OAM,x
    inx
    bne clear_oam_loop
    lda #0
    sta oam_index
    rts

put_sprite:
    ldy oam_index
    lda sprite_y
    sec
    sbc #1
    sta OAM,y
    iny
    lda sprite_tile
    sta OAM,y
    iny
    lda sprite_attr
    sta OAM,y
    iny
    lda sprite_x
    sta OAM,y
    iny
    sty oam_index
    rts

build_game_oam:
    jsr clear_oam
    jsr draw_score_hud
    jsr draw_lives_bombs
    jsr draw_player
    jsr draw_player_bullets
    jsr draw_enemies
    jsr draw_enemy_bullets
    jsr draw_powerup
    rts

build_end_oam:
    jsr clear_oam
    jsr draw_score_hud
    rts

draw_score_hud:
    ; Six score digits use six sprites on scanline 8.  Two extra compact
    ; badges keep us at the NES 8-sprites-per-scanline limit: weapon + stage.
    ldx #0
    lda #8
    sta sprite_x
    lda #8
    sta sprite_y
    lda #3
    sta sprite_attr
draw_score_loop:
    lda score0,x
    clc
    adc #SPR_DIGIT0
    sta sprite_tile
    jsr put_sprite
    lda sprite_x
    clc
    adc #8
    sta sprite_x
    inx
    cpx #6
    bne draw_score_loop

    lda #64
    sta sprite_x
    lda #8
    sta sprite_y
    lda #2
    sta sprite_attr
    lda weapon
    clc
    adc #SPR_WEAPON1
    sta sprite_tile
    jsr put_sprite

    lda #76
    sta sprite_x
    lda #1
    sta sprite_attr
    lda stage
    sec
    sbc #1
    clc
    adc #SPR_STAGE1
    sta sprite_tile
    jsr put_sprite
    rts

draw_lives_bombs:
    lda #20
    sta sprite_y
    lda #0
    sta sprite_attr
    lda #8
    sta sprite_x
    lda #SPR_LIFE
    sta sprite_tile
    ldx #0
draw_lives_loop:
    cpx lives
    bcs draw_lives_done
    jsr put_sprite
    lda sprite_x
    clc
    adc #10
    sta sprite_x
    inx
    jmp draw_lives_loop
draw_lives_done:
    lda #20
    sta sprite_y
    lda #2
    sta sprite_attr
    lda #222
    sta sprite_x
    lda #SPR_BOMB
    sta sprite_tile
    ldx #0
draw_bombs_loop:
    cpx bombs
    bcs draw_bombs_done
    jsr put_sprite
    lda sprite_x
    sec
    sbc #10
    sta sprite_x
    inx
    jmp draw_bombs_loop
draw_bombs_done:
    ; One compact threat gauge sits between lives and bombs.
    lda #120
    sta sprite_x
    lda #20
    sta sprite_y
    lda #1
    sta sprite_attr
    lda threat
    clc
    adc #SPR_THREAT0
    sta sprite_tile
    jsr put_sprite
    rts

draw_player:
    lda invuln
    beq draw_player_visible
    lda frame
    and #4
    bne draw_player_done
draw_player_visible:
    lda #0
    sta sprite_attr
    lda player_x
    sta sprite_x
    lda player_y
    sta sprite_y
    lda #SPR_PLAYER_TL
    sta sprite_tile
    jsr put_sprite
    lda player_x
    clc
    adc #8
    sta sprite_x
    lda #SPR_PLAYER_TR
    sta sprite_tile
    jsr put_sprite
    lda player_x
    sta sprite_x
    lda player_y
    clc
    adc #8
    sta sprite_y
    lda #SPR_PLAYER_BL
    sta sprite_tile
    jsr put_sprite
    lda player_x
    clc
    adc #8
    sta sprite_x
    lda #SPR_PLAYER_BR
    sta sprite_tile
    jsr put_sprite

    ; Separate animated exhaust gives the ship motion without spending CHR-RAM.
    lda player_x
    clc
    adc #4
    sta sprite_x
    lda player_y
    clc
    adc #14
    sta sprite_y
    lda #2
    sta sprite_attr
    lda frame
    and #4
    beq draw_player_thrust_a
    lda #SPR_THRUST_B
    jmp draw_player_thrust_set
draw_player_thrust_a:
    lda #SPR_THRUST_A
draw_player_thrust_set:
    sta sprite_tile
    jsr put_sprite
draw_player_done:
    rts

draw_player_bullets:
    ; Weapon level changes the projectile silhouette as well as shot count.
    lda weapon
    beq draw_pb_weapon_1
    cmp #1
    beq draw_pb_weapon_2
    lda frame
    and #4
    beq draw_pb_weapon_3a
    lda #SPR_PBULLET_3B
    jmp draw_pb_weapon_set
draw_pb_weapon_3a:
    lda #SPR_PBULLET_3
    jmp draw_pb_weapon_set
draw_pb_weapon_2:
    lda #SPR_PBULLET_2
    jmp draw_pb_weapon_set
draw_pb_weapon_1:
    lda #SPR_PBULLET_1
draw_pb_weapon_set:
    sta tmp0
    ldx #0
draw_pb_loop:
    lda PB_Y,x
    cmp #$FF
    beq draw_pb_next
    sta sprite_y
    lda PB_X,x
    sta sprite_x
    lda tmp0
    sta sprite_tile
    lda #2
    sta sprite_attr
    jsr put_sprite
draw_pb_next:
    inx
    cpx #8
    bne draw_pb_loop
    rts

draw_enemies:
    ldx #0
draw_enemy_loop:
    lda EN_TYPE,x
    beq draw_enemy_next
    cmp #4
    beq draw_enemy_boss

    ; Select a stage-specific 16x16 actor.  Each base points at four
    ; row-major tiles; the B tables are a second animation frame.
    tay
    dey                     ; enemy type 1..3 -> Y 0..2
    lda frame
    and #8
    bne draw_enemy_pick_b
    lda stage
    cmp #1
    beq draw_enemy_pick_s1a
    cmp #2
    beq draw_enemy_pick_s2a
    lda enemy_bases_s3a,y
    jmp draw_enemy_base_set
draw_enemy_pick_s1a:
    lda enemy_bases_s1a,y
    jmp draw_enemy_base_set
draw_enemy_pick_s2a:
    lda enemy_bases_s2a,y
    jmp draw_enemy_base_set
draw_enemy_pick_b:
    lda stage
    cmp #1
    beq draw_enemy_pick_s1b
    cmp #2
    beq draw_enemy_pick_s2b
    lda enemy_bases_s3b,y
    jmp draw_enemy_base_set
draw_enemy_pick_s1b:
    lda enemy_bases_s1b,y
    jmp draw_enemy_base_set
draw_enemy_pick_s2b:
    lda enemy_bases_s2b,y
draw_enemy_base_set:
    sta tmp0
    lda #1
    sta sprite_attr

    ; Top-left
    lda EN_X,x
    sta sprite_x
    lda EN_Y,x
    sta sprite_y
    lda tmp0
    sta sprite_tile
    jsr put_sprite
    ; Top-right
    lda EN_X,x
    clc
    adc #8
    sta sprite_x
    lda tmp0
    clc
    adc #1
    sta sprite_tile
    jsr put_sprite
    ; Bottom-left
    lda EN_X,x
    sta sprite_x
    lda EN_Y,x
    clc
    adc #8
    sta sprite_y
    lda tmp0
    clc
    adc #2
    sta sprite_tile
    jsr put_sprite
    ; Bottom-right
    lda EN_X,x
    clc
    adc #8
    sta sprite_x
    lda tmp0
    clc
    adc #3
    sta sprite_tile
    jsr put_sprite
    jmp draw_enemy_next

draw_enemy_boss:
    ; 32x24 / 4x3 carrier. Four sprites per scanline leaves four slots for
    ; projectiles before the classic NES eight-sprite scanline ceiling.
    lda #1
    sta sprite_attr

    lda EN_X,x
    sta sprite_x
    lda EN_Y,x
    sta sprite_y
    lda #SPR_BOSS_0
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #8
    sta sprite_x
    lda #SPR_BOSS_0+1
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #16
    sta sprite_x
    lda #SPR_BOSS_0+2
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #24
    sta sprite_x
    lda #SPR_BOSS_0+3
    sta sprite_tile
    jsr put_sprite

    lda EN_Y,x
    clc
    adc #8
    sta sprite_y
    lda EN_X,x
    sta sprite_x
    lda #SPR_BOSS_0+4
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #8
    sta sprite_x
    lda #SPR_BOSS_0+5
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #16
    sta sprite_x
    lda #SPR_BOSS_0+6
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #24
    sta sprite_x
    lda #SPR_BOSS_0+7
    sta sprite_tile
    jsr put_sprite

    lda EN_Y,x
    clc
    adc #16
    sta sprite_y
    lda EN_X,x
    sta sprite_x
    lda #SPR_BOSS_0+8
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #8
    sta sprite_x
    lda #SPR_BOSS_0+9
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #16
    sta sprite_x
    lda #SPR_BOSS_0+10
    sta sprite_tile
    jsr put_sprite
    lda EN_X,x
    clc
    adc #24
    sta sprite_x
    lda #SPR_BOSS_0+11
    sta sprite_tile
    jsr put_sprite

draw_enemy_next:
    inx
    cpx #ENEMY_SLOTS
    bne draw_enemy_loop
    rts

draw_enemy_bullets:
    ; Projectile art follows the biome, while the boss gets a two-frame orb.
    lda boss_active
    beq draw_eb_stage_pick
    lda frame
    and #4
    beq draw_eb_boss_a
    lda #SPR_EBULLET_BB
    jmp draw_eb_tile_ready
draw_eb_boss_a:
    lda #SPR_EBULLET_BA
    jmp draw_eb_tile_ready
draw_eb_stage_pick:
    lda stage
    cmp #1
    beq draw_eb_s1
    cmp #2
    beq draw_eb_s2
    lda #SPR_EBULLET_S3
    jmp draw_eb_tile_ready
draw_eb_s1:
    lda #SPR_EBULLET_S1
    jmp draw_eb_tile_ready
draw_eb_s2:
    lda #SPR_EBULLET_S2
draw_eb_tile_ready:
    sta tmp0
    ldx #0
draw_eb_loop:
    lda EB_Y,x
    cmp #$FF
    beq draw_eb_next
    sta sprite_y
    lda EB_X,x
    sta sprite_x
    lda tmp0
    sta sprite_tile
    lda #1
    sta sprite_attr
    jsr put_sprite
draw_eb_next:
    inx
    cpx #8
    bne draw_eb_loop
    rts

draw_powerup:
    lda power_active
    beq draw_power_done
    lda power_x
    sta sprite_x
    lda power_y
    sta sprite_y
    lda frame
    lsr A
    lsr A
    and #3
    clc
    adc #SPR_POWER_A
    sta sprite_tile
    lda #2
    sta sprite_attr
    jsr put_sprite
draw_power_done:
    rts

; ============================================================================
; AUDIO - original 2A03 tracker engine v2
; 6 independent 128-step songs, per-song groove, duty animation, decay and drums.
; No DMC or expansion audio. Pulse 2 is temporarily stolen by SFX.
; ============================================================================
apu_init:
    lda #$0F
    sta APUSTATUS
    lda #$40
    sta APUFRAME
    lda #$BF                ; pulse 1: 50%, halt, constant volume
    sta $4000
    lda #$7A                ; pulse 2: 25%, halt, constant volume
    sta $4004
    lda #$FF
    sta $4008
    lda #$10
    sta $400C
    rts

music_tick:
    lda sfx_timer
    beq music_tick_no_sfx
    dec sfx_timer
music_tick_no_sfx:
    lda noise_timer
    beq music_tick_noise_done
    dec noise_timer
    bne music_tick_noise_done
    lda #$10
    sta $400C
music_tick_noise_done:

    ; Shape the two pulse notes every frame instead of holding a flat volume.
    jsr music_apply_envelopes
    jsr music_apply_vibrato

    inc music_div
    ldx music_mode
    lda music_div
    cmp music_speed_table,x
    bcc music_tick_done
    lda #0
    sta music_div

    jsr music_prepare_instruments
    ldx music_step
    lda music_mode
    beq music_select_title
    cmp #1
    beq music_select_stage1
    cmp #2
    beq music_select_stage2
    cmp #3
    beq music_select_core
    cmp #4
    beq music_select_boss
    jmp music_select_win

music_select_title:
    lda melody_title,x
    jsr apu_pulse1_note
    ldx music_step
    lda bass_title,x
    jsr apu_triangle_note
    ldx music_step
    lda harmony_title,x
    jsr apu_pulse2_note_if_free
    ldx music_step
    lda drums_title,x
    jsr music_play_drum
    jmp music_step_advance

music_select_stage1:
    lda melody_stage1,x
    jsr apu_pulse1_note
    ldx music_step
    lda bass_stage1,x
    jsr apu_triangle_note
    ldx music_step
    lda harmony_stage1,x
    jsr apu_pulse2_note_if_free
    ldx music_step
    lda drums_stage1,x
    jsr music_play_drum
    jmp music_step_advance

music_select_stage2:
    lda melody_stage2,x
    jsr apu_pulse1_note
    ldx music_step
    lda bass_stage2,x
    jsr apu_triangle_note
    ldx music_step
    lda harmony_stage2,x
    jsr apu_pulse2_note_if_free
    ldx music_step
    lda drums_stage2,x
    jsr music_play_drum
    jmp music_step_advance

music_select_core:
    lda melody_core,x
    jsr apu_pulse1_note
    ldx music_step
    lda bass_core,x
    jsr apu_triangle_note
    ldx music_step
    lda harmony_core,x
    jsr apu_pulse2_note_if_free
    ldx music_step
    lda drums_core,x
    jsr music_play_drum
    jmp music_step_advance

music_select_boss:
    lda melody_boss,x
    jsr apu_pulse1_note
    ldx music_step
    lda bass_boss,x
    jsr apu_triangle_note
    ldx music_step
    lda harmony_boss,x
    jsr apu_pulse2_note_if_free
    ldx music_step
    lda drums_boss,x
    jsr music_play_drum
    jmp music_step_advance

music_select_win:
    lda melody_win,x
    jsr apu_pulse1_note
    ldx music_step
    lda bass_win,x
    jsr apu_triangle_note
    ldx music_step
    lda harmony_win,x
    jsr apu_pulse2_note_if_free
    ldx music_step
    lda drums_win,x
    jsr music_play_drum

music_step_advance:
    inc music_step
    lda music_step
    cmp #128
    bcc music_tick_done
    lda #0
    sta music_step
music_tick_done:
    rts

; Change square-wave timbre every half-bar. The timbre movement is part of each
; track's arrangement rather than an effect copied from another soundtrack.
music_prepare_instruments:
    ldx music_mode
    lda music_step
    and #$08
    beq music_lead_duty_a
    lda lead_duty_b,x
    jmp music_lead_duty_store
music_lead_duty_a:
    lda lead_duty_a,x
music_lead_duty_store:
    sta music_lead_ctl

    lda music_step
    and #$04
    beq music_harm_duty_a
    lda harm_duty_b,x
    jmp music_harm_duty_store
music_harm_duty_a:
    lda harm_duty_a,x
music_harm_duty_store:
    sta music_harm_ctl
    rts

music_apply_envelopes:
    lda music_lead_on
    beq music_env_harmony
    ldx music_div
    lda lead_volume_table,x
    ora music_lead_ctl
    sta $4000
music_env_harmony:
    lda music_harm_on
    beq music_env_done
    lda sfx_timer
    bne music_env_done
    ldx music_div
    lda harm_volume_table,x
    ora music_harm_ctl
    sta $4004
music_env_done:
    rts

; Tiny +/-1 timer motion after the attack gives the lead life without consuming
; another channel. Avoid low-byte wrap so the high timer byte remains correct.
music_apply_vibrato:
    lda music_lead_on
    beq music_vibrato_done
    lda music_div
    cmp #2
    bcc music_vibrato_done
    lda music_lead_note
    beq music_vibrato_done
    sec
    sbc #1
    tax
    lda frame
    and #$03
    cmp #1
    beq music_vibrato_up
    cmp #3
    beq music_vibrato_down
    lda pulse_period_lo,x
    sta $4002
    rts
music_vibrato_up:
    lda pulse_period_lo,x
    cmp #$FF
    beq music_vibrato_done
    clc
    adc #1
    sta $4002
    rts
music_vibrato_down:
    lda pulse_period_lo,x
    beq music_vibrato_done
    sec
    sbc #1
    sta $4002
music_vibrato_done:
    rts

apu_pulse1_note:
    sta music_lead_note
    beq apu_pulse1_rest
    lda #1
    sta music_lead_on
    lda music_lead_note
    sec
    sbc #1
    tax
    lda music_lead_ctl
    ora #$0F
    sta $4000
    lda pulse_period_lo,x
    sta $4002
    lda pulse_period_hi,x
    ora #$F8
    sta $4003
    rts
apu_pulse1_rest:
    lda #0
    sta music_lead_on
    lda music_lead_ctl
    sta $4000
    rts

apu_pulse2_note_if_free:
    sta music_harm_note
    ldy sfx_timer
    beq apu_pulse2_sfx_free
    lda #0
    sta music_harm_on
    rts
apu_pulse2_sfx_free:
    lda music_harm_note
    beq apu_pulse2_rest
    lda #1
    sta music_harm_on
    lda music_harm_note
    sec
    sbc #1
    tax
    lda music_harm_ctl
    ora #$0A
    sta $4004
    lda pulse_period_lo,x
    sta $4006
    lda pulse_period_hi,x
    ora #$F8
    sta $4007
    rts
apu_pulse2_rest:
    lda #0
    sta music_harm_on
    lda music_harm_ctl
    sta $4004
apu_pulse2_done:
    rts

apu_triangle_note:
    beq apu_triangle_rest
    sec
    sbc #1
    tax
    lda #$FF
    sta $4008
    lda tri_period_lo,x
    sta $400A
    lda tri_period_hi,x
    ora #$F8
    sta $400B
    rts
apu_triangle_rest:
    lda #$80
    sta $4008
    rts

; Drum event values: 0 rest, 1 metallic hat, 2 snare, 3 low kick/tom, 4 crash.
; Hardware noise envelopes create short attacks rather than flat noise bursts.
music_play_drum:
    beq music_drum_done
    ldy noise_timer
    bne music_drum_done
    cmp #1
    beq music_drum_hat
    cmp #2
    beq music_drum_snare
    cmp #3
    beq music_drum_kick
    ; crash
    lda #4
    sta noise_timer
    lda #$02
    sta $400C
    lda #$82
    sta $400E
    lda #$18
    sta $400F
    rts
music_drum_hat:
    lda #2
    sta noise_timer
    lda #$01
    sta $400C
    lda #$81
    sta $400E
    lda #$08
    sta $400F
    rts
music_drum_snare:
    lda #3
    sta noise_timer
    lda #$03
    sta $400C
    lda #$05
    sta $400E
    lda #$10
    sta $400F
    rts
music_drum_kick:
    lda #3
    sta noise_timer
    lda #$04
    sta $400C
    lda #$0D
    sta $400E
    lda #$18
    sta $400F
music_drum_done:
    rts

; Gameplay sound effects keep the stronger constant-volume character and may
; temporarily steal Pulse 2 or Noise. Music resumes automatically afterwards.
sfx_shot:
    lda #3
    sta sfx_timer
    lda #$5F
    sta $4004
    lda #$38
    sta $4006
    lda #$F8
    sta $4007
    rts

sfx_hit:
    lda #3
    sta noise_timer
    lda #$1B
    sta $400C
    lda #$02
    sta $400E
    lda #$10
    sta $400F
    rts

sfx_explosion:
    lda #10
    sta noise_timer
    lda #$1F
    sta $400C
    lda #$06
    sta $400E
    lda #$18
    sta $400F
    rts

sfx_bomb:
    lda #18
    sta noise_timer
    lda #$1F
    sta $400C
    lda #$0E
    sta $400E
    lda #$28
    sta $400F
    rts

sfx_power:
    lda #6
    sta sfx_timer
    lda #$5C
    sta $4004
    lda #$70
    sta $4006
    lda #$F8
    sta $4007
    rts

sfx_start:
    lda #8
    sta sfx_timer
    lda #$5F
    sta $4004
    lda #$A0
    sta $4006
    lda #$F8
    sta $4007
    rts

; ============================================================================
; DATA
; ============================================================================
spawn_x_table:
    .byte 24, 200, 56, 168, 96, 224, 40, 144, 216, 72, 184, 112, 32, 152, 232, 88

; 16x16 regular-enemy tile bases. Each entry owns four consecutive tiles.
enemy_bases_s1a:
    .byte 96,104,112
enemy_bases_s1b:
    .byte 100,108,116
enemy_bases_s2a:
    .byte 120,128,136
enemy_bases_s2b:
    .byte 124,132,140
enemy_bases_s3a:
    .byte 144,152,160
enemy_bases_s3b:
    .byte 148,156,164

; Chromatic note index 1..48 = C2..B5 (0 = rest).
; Generated from the NTSC 2A03 clock, not a borrowed commercial pitch table.
pulse_period_lo:
    .byte $AD,$4D,$F3,$9D,$4C,$00,$B8,$74,$34,$F8,$BF,$89,$56,$26,$F9,$CE
    .byte $A6,$80,$5C,$3A,$1A,$FB,$DF,$C4,$AB,$93,$7C,$67,$52,$3F,$2D,$1C
    .byte $0C,$FD,$EF,$E1,$D5,$C9,$BD,$B3,$A9,$9F,$96,$8E,$86,$7E,$77,$70
pulse_period_hi:
    .byte $06,$06,$05,$05,$05,$05,$04,$04,$04,$03,$03,$03,$03,$03,$02,$02
    .byte $02,$02,$02,$02,$02,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01,$01
    .byte $01,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
tri_period_lo:
    .byte $56,$26,$F9,$CE,$A6,$80,$5C,$3A,$1A,$FB,$DF,$C4,$AB,$93,$7C,$67
    .byte $52,$3F,$2D,$1C,$0C,$FD,$EF,$E1,$D5,$C9,$BD,$B3,$A9,$9F,$96,$8E
    .byte $86,$7E,$77,$70,$6A,$64,$5E,$59,$54,$4F,$4B,$46,$42,$3F,$3B,$38
tri_period_hi:
    .byte $03,$03,$02,$02,$02,$02,$02,$02,$02,$01,$01,$01,$01,$01,$01,$01
    .byte $01,$01,$01,$01,$01,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
    .byte $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00

; Song modes: 0 title, 1 stage1, 2 stage2, 3 core/stage3, 4 boss, 5 victory.
music_speed_table:
    .byte 6,5,5,4,4,7
lead_duty_a:
    .byte $70,$70,$B0,$30,$70,$B0
lead_duty_b:
    .byte $B0,$30,$F0,$B0,$30,$70
harm_duty_a:
    .byte $30,$B0,$70,$F0,$30,$70
harm_duty_b:
    .byte $70,$F0,$30,$70,$B0,$B0
lead_volume_table:
    .byte 15,14,12,10,8,6,4,3
harm_volume_table:
    .byte 10,9,8,7,6,5,4,3

; TITLE - original 128-step arrangement
melody_title:
    .byte 31,0,38,0,34,0,41,0,38,36,34,31,0,29,31,0
    .byte 31,0,34,36,38,0,41,0,39,38,34,33,31,0,38,0
    .byte 34,0,38,41,43,41,38,36,34,0,33,36,38,0,41,0
    .byte 39,38,36,34,33,31,29,0,31,34,38,0,36,33,31,0
    .byte 38,0,41,43,46,0,45,41,38,36,34,0,31,33,34,0
    .byte 36,38,41,0,39,38,34,33,31,0,29,31,38,0,34,0
    .byte 31,34,38,41,43,0,41,38,36,0,34,31,33,36,38,0
    .byte 41,39,38,34,36,33,31,29,31,0,38,0,34,33,31,0
harmony_title:
    .byte 19,0,26,0,22,0,26,0,19,0,26,0,29,0,26,0
    .byte 15,0,22,0,31,0,22,0,15,0,22,0,29,0,22,0
    .byte 17,0,24,0,33,0,24,0,17,0,24,0,31,0,24,0
    .byte 14,0,21,0,26,0,21,0,14,0,21,0,24,0,21,0
    .byte 19,0,22,0,26,0,29,0,19,0,26,0,34,0,29,0
    .byte 15,0,22,0,26,0,31,0,17,0,24,0,27,0,33,0
    .byte 14,0,21,0,24,0,29,0,14,0,21,0,26,0,29,0
    .byte 19,0,26,0,29,0,34,0,19,0,26,0,22,0,26,0
bass_title:
    .byte 7,0,0,0,14,0,0,0,15,0,0,0,17,0,0,0
    .byte 7,0,0,0,14,0,0,0,15,0,0,0,14,0,0,0
    .byte 5,0,0,0,12,0,0,0,14,0,0,0,9,0,0,0
    .byte 5,0,0,0,12,0,0,0,15,0,0,0,14,0,0,0
    .byte 7,0,0,0,14,0,0,0,15,0,0,0,10,0,0,0
    .byte 5,0,0,0,12,0,0,0,14,0,0,0,9,0,0,0
    .byte 14,0,0,0,9,0,0,0,5,0,0,0,12,0,0,0
    .byte 7,0,0,0,14,0,0,0,17,0,0,0,14,0,0,0
drums_title:
    .byte 4,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 4,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0

; STAGE1 - original 128-step arrangement
melody_stage1:
    .byte 39,0,42,44,46,0,37,34,39,41,42,46,44,41,39,0
    .byte 39,0,34,37,39,42,41,37,34,37,38,39,42,41,39,0
    .byte 34,37,39,0,42,46,44,41,39,0,37,34,37,39,41,44
    .byte 42,41,39,37,34,0,39,41,42,46,37,34,32,34,37,0
    .byte 39,42,46,37,39,0,41,42,46,44,41,39,37,34,37,38
    .byte 39,0,42,44,46,37,34,32,30,34,37,39,41,39,37,0
    .byte 34,0,39,42,41,37,39,34,37,39,42,46,44,41,39,38
    .byte 39,34,37,41,42,41,39,37,34,32,34,37,39,0,34,0
harmony_stage1:
    .byte 27,34,37,34,29,34,37,34,27,34,37,41,30,34,37,34
    .byte 27,34,37,34,32,39,36,39,25,32,34,32,29,34,37,34
    .byte 30,37,34,37,27,34,37,34,32,39,36,39,29,36,32,36
    .byte 27,34,37,34,30,37,34,37,29,36,32,36,27,34,37,34
    .byte 27,34,37,41,30,37,34,37,32,39,36,39,25,32,34,37
    .byte 27,34,37,34,29,36,32,36,30,37,34,37,29,34,37,34
    .byte 32,39,36,39,30,37,34,37,27,34,37,34,29,36,32,36
    .byte 27,34,37,41,30,37,34,37,29,34,37,34,27,0,34,0
bass_stage1:
    .byte 3,0,10,15,13,0,10,13,3,0,10,15,8,0,10,13
    .byte 3,0,10,15,13,0,8,13,6,0,13,18,5,0,12,17
    .byte 3,0,10,15,8,0,15,20,13,0,8,13,5,0,12,17
    .byte 6,0,13,18,3,0,10,15,5,0,12,17,3,0,10,13
    .byte 3,0,10,15,6,0,13,18,8,0,15,20,13,0,8,13
    .byte 3,0,10,15,5,0,12,17,6,0,13,18,5,0,12,17
    .byte 8,0,15,20,6,0,13,18,3,0,10,15,5,0,12,17
    .byte 3,0,10,15,13,0,8,13,10,0,17,22,3,0,10,15
drums_stage1:
    .byte 3,1,1,1,2,1,3,1,3,1,1,3,2,1,3,1
    .byte 3,1,1,3,2,1,3,1,3,1,4,1,2,1,3,1
    .byte 3,1,1,1,2,1,3,1,3,1,1,3,2,1,3,1
    .byte 3,1,3,1,2,1,1,3,3,1,1,1,2,3,1,1
    .byte 3,1,1,1,2,1,3,1,3,1,1,3,2,1,3,1
    .byte 3,1,1,1,2,1,3,1,3,4,1,3,2,1,3,1
    .byte 3,1,1,1,2,1,3,1,3,1,1,3,2,1,3,1
    .byte 3,1,3,1,2,1,3,1,4,1,1,3,2,3,1,1

; STAGE2 - original 128-step arrangement
melody_stage2:
    .byte 41,0,42,45,48,46,45,42,41,36,37,39,42,41,39,37
    .byte 36,0,41,42,45,0,48,46,45,42,41,39,37,36,42,0
    .byte 41,36,42,37,45,39,46,41,48,46,45,42,41,0,39,37
    .byte 36,37,39,42,41,45,42,39,37,36,41,42,45,48,46,0
    .byte 41,42,45,48,46,45,42,41,39,37,36,41,42,39,37,36
    .byte 41,0,48,45,42,41,39,37,36,42,41,37,39,36,41,0
    .byte 45,42,41,36,37,39,42,46,45,41,42,39,37,36,41,42
    .byte 45,48,46,42,41,39,37,36,42,41,39,37,36,0,41,0
harmony_stage2:
    .byte 29,0,36,0,30,0,37,0,29,36,33,36,30,37,34,37
    .byte 29,0,36,41,27,34,30,34,25,32,29,32,24,30,27,30
    .byte 29,36,30,37,33,39,34,41,36,42,34,41,33,39,30,37
    .byte 29,0,36,41,30,37,34,37,27,34,30,34,25,32,29,32
    .byte 29,36,33,36,30,37,34,37,27,34,30,34,25,32,29,32
    .byte 29,0,36,41,33,39,36,39,30,37,34,37,29,36,33,36
    .byte 25,32,29,32,27,34,30,34,29,36,33,36,30,37,34,37
    .byte 29,36,33,36,27,34,30,34,25,32,29,32,29,0,36,0
bass_stage2:
    .byte 5,0,12,17,6,0,13,18,5,0,12,17,3,0,10,15
    .byte 1,0,8,13,12,0,7,12,5,0,12,17,6,0,13,18
    .byte 5,0,12,17,3,0,10,15,1,0,8,13,12,0,7,12
    .byte 5,0,12,17,6,0,13,18,3,0,10,15,1,0,8,13
    .byte 5,0,12,17,6,0,13,18,3,0,10,15,1,0,8,13
    .byte 5,0,12,17,9,0,16,21,6,0,13,18,5,0,12,17
    .byte 1,0,8,13,3,0,10,15,5,0,12,17,6,0,13,18
    .byte 5,0,12,17,3,0,10,15,1,0,8,13,5,0,12,17
drums_stage2:
    .byte 3,1,0,1,2,1,3,1,0,1,3,1,2,0,3,1
    .byte 3,1,0,1,2,1,3,1,0,1,3,1,2,0,3,1
    .byte 3,1,4,1,2,1,0,3,3,1,0,1,2,3,1,1
    .byte 3,1,4,1,2,1,0,3,3,1,0,1,2,3,1,1
    .byte 3,1,0,3,2,1,3,1,0,4,1,1,2,1,3,1
    .byte 3,1,0,3,2,1,3,1,0,4,1,1,2,1,3,1
    .byte 3,1,3,1,2,0,1,3,4,1,0,1,2,3,1,1
    .byte 3,1,3,1,2,0,1,3,4,1,0,1,2,3,1,1

; CORE - original 128-step arrangement
melody_core:
    .byte 38,39,38,32,41,39,38,0,44,45,41,39,38,32,36,0
    .byte 38,41,44,47,45,44,41,39,38,0,32,38,39,41,44,0
    .byte 44,41,38,39,45,44,41,38,35,36,38,41,39,38,32,0
    .byte 38,39,41,44,45,41,39,38,36,32,38,35,36,39,38,0
    .byte 38,44,39,45,41,47,44,41,39,38,36,32,35,36,39,41
    .byte 44,0,41,39,38,36,35,32,38,39,44,41,39,38,32,0
    .byte 38,41,39,44,41,45,44,39,38,35,36,38,41,44,39,0
    .byte 45,44,41,39,38,36,32,35,36,39,41,44,39,38,38,0
harmony_core:
    .byte 26,32,27,33,29,35,32,39,26,32,36,41,27,33,29,35
    .byte 26,32,27,33,29,35,32,39,24,30,26,32,27,33,29,35
    .byte 32,39,29,35,26,32,27,33,29,36,26,32,23,29,24,30
    .byte 26,32,27,33,29,35,32,39,27,34,29,36,26,32,29,35
    .byte 26,32,29,36,27,33,30,36,26,32,27,33,23,29,24,30
    .byte 26,32,27,34,29,35,32,39,27,33,29,36,26,32,27,33
    .byte 29,35,32,39,26,32,27,33,24,30,26,32,23,29,24,30
    .byte 26,32,27,33,29,35,32,39,26,32,36,41,27,33,26,0
bass_core:
    .byte 2,0,8,0,14,0,8,0,3,0,10,0,2,0,8,0
    .byte 2,0,8,0,5,0,12,0,3,0,10,0,2,0,8,0
    .byte 8,0,15,0,2,0,8,0,11,0,17,0,2,0,8,0
    .byte 2,0,8,0,3,0,10,0,5,0,12,0,2,0,8,0
    .byte 2,0,8,0,5,0,12,0,3,0,10,0,11,0,17,0
    .byte 2,0,8,0,3,0,10,0,5,0,12,0,2,0,8,0
    .byte 5,0,12,0,2,0,8,0,3,0,10,0,11,0,17,0
    .byte 2,0,8,0,3,0,10,0,5,0,12,0,2,0,14,0
drums_core:
    .byte 3,1,1,3,1,1,2,1,3,1,1,3,1,1,2,1
    .byte 3,1,1,3,1,1,2,1,3,1,1,3,1,1,2,1
    .byte 3,1,4,3,1,1,2,1,3,1,4,3,1,1,2,1
    .byte 3,1,4,3,1,1,2,1,3,1,4,3,1,1,2,1
    .byte 3,1,1,3,1,3,2,1,3,1,1,3,1,3,2,1
    .byte 3,1,1,3,1,3,2,1,3,1,1,3,1,3,2,1
    .byte 4,1,1,3,1,1,2,3,4,1,1,3,1,1,2,3
    .byte 4,1,1,3,1,1,2,3,4,1,1,3,1,1,2,3

; BOSS - original 128-step arrangement
melody_boss:
    .byte 42,37,45,39,42,37,43,38,46,40,45,39,43,38,42,37
    .byte 42,45,37,39,43,46,38,40,42,37,45,39,43,38,46,0
    .byte 37,42,39,45,38,43,40,46,37,42,45,39,38,43,46,40
    .byte 42,0,37,45,39,43,38,46,40,45,39,42,37,43,38,0
    .byte 46,45,42,39,43,42,38,37,45,46,40,39,42,43,37,38
    .byte 42,37,45,39,43,38,46,40,45,39,42,37,43,38,42,0
    .byte 42,45,46,39,43,46,45,38,42,37,40,39,43,38,45,37
    .byte 42,37,43,38,45,39,46,40,42,39,38,37,42,0,42,0
harmony_boss:
    .byte 18,25,33,25,19,26,34,26,18,25,33,27,19,26,34,28
    .byte 18,25,33,27,19,26,34,28,25,32,39,32,26,33,40,33
    .byte 18,25,33,25,19,26,34,26,16,23,30,23,15,22,31,22
    .byte 18,25,33,27,19,26,34,28,18,25,33,25,19,26,34,26
    .byte 23,30,37,30,24,31,38,31,18,25,33,27,19,26,34,28
    .byte 18,25,33,25,19,26,34,26,16,23,30,23,15,22,31,22
    .byte 18,25,33,27,19,26,34,28,25,32,39,32,26,33,40,33
    .byte 18,25,33,25,19,26,34,26,18,25,33,27,18,0,25,0
bass_boss:
    .byte 6,0,13,0,6,13,7,0,14,0,7,14,6,0,13,0
    .byte 6,0,13,0,7,0,14,0,11,0,18,0,14,0,9,0
    .byte 6,0,13,0,7,0,14,0,4,0,11,0,3,0,10,0
    .byte 6,0,13,0,7,0,14,0,6,0,13,0,7,0,14,0
    .byte 11,0,18,0,12,0,19,0,6,0,13,0,7,0,14,0
    .byte 6,0,13,0,4,0,11,0,3,0,10,0,7,0,14,0
    .byte 6,0,13,0,7,0,14,0,1,0,8,0,2,0,9,0
    .byte 6,0,13,0,7,0,14,0,6,0,13,0,6,0,13,0
drums_boss:
    .byte 3,1,1,3,2,1,3,1,3,1,1,3,2,1,3,1
    .byte 3,1,1,3,2,1,3,1,3,1,1,3,2,1,3,1
    .byte 4,1,1,3,2,1,3,1,4,1,1,3,2,1,3,1
    .byte 4,1,1,3,2,1,3,1,4,1,1,3,2,1,3,1
    .byte 3,1,3,1,2,3,1,1,3,1,3,1,2,3,1,1
    .byte 3,1,3,1,2,3,1,1,3,1,3,1,2,3,1,1
    .byte 4,1,1,3,2,1,4,3,4,1,1,3,2,1,4,3
    .byte 4,1,1,3,2,1,4,3,4,1,1,3,2,1,4,3

; WIN - original 128-step arrangement
melody_win:
    .byte 27,0,31,34,39,0,38,34,36,0,34,31,29,31,34,0
    .byte 27,31,34,39,41,0,38,34,36,34,31,29,27,0,34,0
    .byte 32,0,36,39,43,41,39,36,34,0,38,41,39,38,34,31
    .byte 29,31,34,38,36,34,31,29,27,0,31,34,39,0,34,0
    .byte 27,31,34,38,39,41,43,41,39,38,34,31,32,34,36,0
    .byte 34,38,41,39,38,36,34,31,29,0,31,34,39,38,34,0
    .byte 32,36,39,43,41,39,36,34,31,34,38,41,39,38,34,31
    .byte 29,31,34,36,39,38,34,31,27,0,34,0,39,0,27,0
harmony_win:
    .byte 15,0,22,0,31,0,22,0,20,0,27,0,24,0,27,0
    .byte 15,0,22,0,31,0,22,0,17,0,24,0,20,0,24,0
    .byte 20,0,27,0,24,0,27,0,22,0,29,0,26,0,29,0
    .byte 15,0,22,0,31,0,22,0,17,0,24,0,20,0,24,0
    .byte 15,0,22,0,31,0,22,0,20,0,27,0,24,0,27,0
    .byte 22,0,29,0,26,0,29,0,15,0,22,0,31,0,22,0
    .byte 20,0,27,0,24,0,27,0,22,0,29,0,26,0,29,0
    .byte 15,0,22,0,31,0,22,0,15,0,22,0,27,0,22,0
bass_win:
    .byte 3,0,0,0,10,0,0,0,8,0,0,0,15,0,0,0
    .byte 3,0,0,0,10,0,0,0,5,0,0,0,12,0,0,0
    .byte 8,0,0,0,15,0,0,0,10,0,0,0,17,0,0,0
    .byte 3,0,0,0,10,0,0,0,5,0,0,0,12,0,0,0
    .byte 3,0,0,0,10,0,0,0,8,0,0,0,15,0,0,0
    .byte 10,0,0,0,17,0,0,0,3,0,0,0,10,0,0,0
    .byte 8,0,0,0,15,0,0,0,10,0,0,0,17,0,0,0
    .byte 3,0,0,0,10,0,0,0,3,0,0,0,15,0,0,0
drums_win:
    .byte 4,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0
    .byte 2,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0

palette_title:
    .byte $0F,$06,$17,$27,  $0F,$01,$12,$31,  $0F,$03,$13,$2C,  $0F,$00,$10,$30
    .byte $0F,$0C,$2C,$30,  $0F,$06,$16,$27,  $0F,$17,$28,$30,  $0F,$03,$13,$30
palette_stage1:
    .byte $0F,$01,$11,$21,  $0F,$07,$17,$27,  $0F,$03,$13,$23,  $0F,$00,$10,$30
    .byte $0F,$0C,$2C,$30,  $0F,$06,$16,$27,  $0F,$17,$28,$30,  $0F,$03,$13,$30
palette_stage2:
    .byte $0F,$03,$13,$23,  $0F,$0C,$1C,$2C,  $0F,$04,$14,$24,  $0F,$00,$10,$30
    .byte $0F,$0C,$2C,$30,  $0F,$05,$15,$25,  $0F,$17,$28,$30,  $0F,$03,$13,$30
palette_stage3:
    .byte $0F,$06,$16,$27,  $0F,$07,$17,$28,  $0F,$03,$13,$23,  $0F,$00,$10,$30
    .byte $0F,$0C,$2C,$30,  $0F,$06,$16,$27,  $0F,$17,$28,$30,  $0F,$03,$13,$30
palette_win:
    .byte $0F,$01,$11,$31,  $0F,$09,$19,$29,  $0F,$0A,$1A,$2A,  $0F,$00,$10,$30
    .byte $0F,$0C,$2C,$30,  $0F,$09,$19,$29,  $0F,$17,$28,$30,  $0F,$03,$13,$30

; Nametables are generated from original tile art by tools/gen_assets.py.
title_nam:
    .incbin "assets/title.nam"
stage1_nam:
    .incbin "assets/stage1.nam"
stage2_nam:
    .incbin "assets/stage2.nam"
stage3_nam:
    .incbin "assets/stage3.nam"
gameover_nam:
    .incbin "assets/gameover.nam"
win_nam:
    .incbin "assets/win.nam"

; Interrupt vectors must live at the end of the 32 KiB PRG image.
.org $FFFA
    .word nmi
    .word reset
    .word irq
