#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import random

ROOT=Path(__file__).resolve().parents[1]
AS=ROOT/'assets'
AS.mkdir(exist_ok=True)

FONT = {
'A':["01110","10001","10001","11111","10001","10001","10001"],
'B':["11110","10001","10001","11110","10001","10001","11110"],
'C':["01111","10000","10000","10000","10000","10000","01111"],
'D':["11110","10001","10001","10001","10001","10001","11110"],
'E':["11111","10000","10000","11110","10000","10000","11111"],
'F':["11111","10000","10000","11110","10000","10000","10000"],
'G':["01111","10000","10000","10111","10001","10001","01111"],
'H':["10001","10001","10001","11111","10001","10001","10001"],
'I':["11111","00100","00100","00100","00100","00100","11111"],
'J':["00111","00010","00010","00010","10010","10010","01100"],
'K':["10001","10010","10100","11000","10100","10010","10001"],
'L':["10000","10000","10000","10000","10000","10000","11111"],
'M':["10001","11011","10101","10101","10001","10001","10001"],
'N':["10001","11001","10101","10011","10001","10001","10001"],
'O':["01110","10001","10001","10001","10001","10001","01110"],
'P':["11110","10001","10001","11110","10000","10000","10000"],
'Q':["01110","10001","10001","10001","10101","10010","01101"],
'R':["11110","10001","10001","11110","10100","10010","10001"],
'S':["01111","10000","10000","01110","00001","00001","11110"],
'T':["11111","00100","00100","00100","00100","00100","00100"],
'U':["10001","10001","10001","10001","10001","10001","01110"],
'V':["10001","10001","10001","10001","10001","01010","00100"],
'W':["10001","10001","10001","10101","10101","10101","01010"],
'X':["10001","10001","01010","00100","01010","10001","10001"],
'Y':["10001","10001","01010","00100","00100","00100","00100"],
'Z':["11111","00001","00010","00100","01000","10000","11111"],
'0':["01110","10001","10011","10101","11001","10001","01110"],
'1':["00100","01100","00100","00100","00100","00100","01110"],
'2':["01110","10001","00001","00010","00100","01000","11111"],
'3':["11110","00001","00001","01110","00001","00001","11110"],
'4':["00010","00110","01010","10010","11111","00010","00010"],
'5':["11111","10000","10000","11110","00001","00001","11110"],
'6':["01110","10000","10000","11110","10001","10001","01110"],
'7':["11111","00001","00010","00100","01000","01000","01000"],
'8':["01110","10001","10001","01110","10001","10001","01110"],
'9':["01110","10001","10001","01111","00001","00001","01110"],
'-':["00000","00000","00000","11111","00000","00000","00000"],
'.':["00000","00000","00000","00000","00000","00110","00110"],
':':["00000","00110","00110","00000","00110","00110","00000"],
'/':["00001","00010","00010","00100","01000","01000","10000"],
'!':["00100","00100","00100","00100","00100","00000","00100"],
'>':["10000","01000","00100","00010","00100","01000","10000"],
'<':["00001","00010","00100","01000","00100","00010","00001"],
'(':["00010","00100","01000","01000","01000","00100","00010"],
')':["01000","00100","00010","00010","00010","00100","01000"],
'=':["00000","11111","00000","11111","00000","00000","00000"],
}

def blank(): return [[0]*8 for _ in range(8)]
def tile_from_rows(rows):
    t=blank()
    for y,row in enumerate(rows):
        for x,ch in enumerate(row): t[y][x]=int(ch)
    return t

def encode_tile(t):
    p0=[]; p1=[]
    for row in t:
        b0=b1=0
        for x,v in enumerate(row):
            bit=7-x
            b0 |= (v&1)<<bit
            b1 |= ((v>>1)&1)<<bit
        p0.append(b0); p1.append(b1)
    return bytes(p0+p1)

def glyph_tile(ch,color=3):
    t=blank(); pat=FONT.get(ch)
    if not pat: return t
    for y,row in enumerate(pat):
        for x,b in enumerate(row):
            if b=='1': t[y][x+1]=color
    return t

def big_glyph_tiles(ch,color=3):
    # 16x24 title glyph.  Commercial late-NES shooters rarely used a plain
    # doubled system font for the logo: they used broad masses, bevels and
    # contrasting value bands.  Scale the 5x7 skeleton to 3x and shade the
    # filled strokes vertically so each letter reads as a tiny metal plate.
    c=[[0]*16 for _ in range(24)]; pat=FONT[ch]
    ox,oy=0,1
    mask=[[0]*16 for _ in range(24)]
    for y,row in enumerate(pat):
        for x,b in enumerate(row):
            if b=='1':
                for yy in range(3):
                    for xx in range(3):
                        px=ox+x*3+xx; py=oy+y*3+yy
                        if 0<=px<16 and 0<=py<24: mask[py][px]=1
    # One-pixel down/right shadow makes the silhouette chunkier without a box.
    for y in range(23):
        for x in range(15):
            if mask[y][x] and not mask[y+1][x+1]: c[y+1][x+1]=1
    # Warm three-band bevel. Pixel values map through the chosen BG subpalette.
    for y in range(24):
        for x in range(16):
            if not mask[y][x]: continue
            if y < 8: v=3
            elif y < 16: v=2
            else: v=1
            # Small specular chips on exposed upper edges keep it pixel-art,
            # rather than looking like a flat vector font.
            if y>0 and not mask[y-1][x] and ((x+y)&1)==0: v=3
            c[y][x]=v
    out=[]
    for by in (0,8,16):
        for bx in (0,8): out.append([r[bx:bx+8] for r in c[by:by+8]])
    return out

def make_bg_chr():
    tiles=[blank() for _ in range(256)]

    # ------------------------------------------------------------------
    # Shared space / scenery tiles.  The first version leaned too much on
    # one-pixel lines.  These use chunky silhouettes, dithering and solid
    # masses so the screen reads like late-80s cartridge art at a glance.
    # ------------------------------------------------------------------
    tiles[1]=tile_from_rows([
        "00000000","00000000","00001000","00000000",
        "00000000","00000000","00000000","00000000"])
    tiles[2]=tile_from_rows([
        "00000000","00010000","00121000","01232100",
        "00121000","00010000","00000000","00000000"])
    tiles[3]=tile_from_rows([
        "10000000","00000020","00010000","00000000",
        "00000001","02000000","00000000","00001000"])
    tiles[4]=tile_from_rows([
        "00000000","00101000","01010100","10101010",
        "01010101","00101010","00010100","00000000"])
    tiles[5]=tile_from_rows([
        "00101100","01212100","12121210","21212121",
        "12121212","01212120","00121200","00011000"])
    tiles[6]=tile_from_rows([
        "00000000","00011000","00122100","01233210",
        "01233210","00122100","00011000","00000000"])

    # 16x16 asteroid: four tiles (7-10), intentionally irregular and filled.
    asteroid=[
        "0000000011100000","0000011122211000","0001122233322100","0012233333333210",
        "0123333322233321","1233332211223332","2333322111223333","2333221112233333",
        "3333221122333332","3333322233333322","2333333333333221","1233333333322110",
        "0122333333221000","0011223322110000","0000112211000000","0000001100000000"]
    ac=[[int(ch) for ch in row] for row in asteroid]
    for i,t in enumerate(canvas_to_tiles(ac) if 'canvas_to_tiles' in globals() else []):
        tiles[7+i]=t
    # canvas_to_tiles is defined below in source order; explicitly slice here.
    if not any(any(r) for r in tiles[7]):
        for i,(by,bx) in enumerate(((0,0),(0,8),(8,0),(8,8))):
            tiles[7+i]=[r[bx:bx+8] for r in ac[by:by+8]]

    # Tiny debris / comet.
    tiles[11]=tile_from_rows([
        "00000000","30000000","23000000","12310000",
        "01232100","00123100","00011000","00000000"])

    # Orbital hull set, 12-19.  These intentionally connect across tile
    # boundaries; repeating them should read as a large structure, not a grid.
    tiles[12]=tile_from_rows([
        "33333322","33333221","33332211","33332211",
        "33332211","33332211","33333221","33333322"])
    tiles[13]=tile_from_rows([
        "22333333","12233333","11223333","11223333",
        "11223333","11223333","12233333","22333333"])
    tiles[14]=tile_from_rows([
        "33333333","33222222","33222222","33333333",
        "33333333","32222222","32222222","33333333"])
    tiles[15]=tile_from_rows([
        "33333333","33333333","32211223","32233223",
        "32233223","32211223","33333333","33333333"])
    tiles[16]=tile_from_rows([
        "33222233","32111123","32133123","32133123",
        "32133123","32133123","32111123","33222233"])
    tiles[17]=tile_from_rows([
        "33333333","33333333","32222223","32121213",
        "32121213","32222223","33333333","33333333"])
    tiles[18]=tile_from_rows([
        "33322333","33233233","32333323","23311332",
        "23311332","32333323","33233233","33322333"])
    tiles[19]=tile_from_rows([
        "33333310","33333210","33332100","33321000",
        "33321000","33332100","33333210","33333310"])

    # Core-relay / machinery tiles, 20-29.  Use chunky blocks, sockets and
    # cables; only the dedicated hazard tile uses a repeated stripe.
    tiles[20]=tile_from_rows([
        "33333333","33333333","33222233","33222233",
        "33222233","33222233","33333333","33333333"])
    tiles[21]=tile_from_rows([
        "33333333","33222233","32111123","32133123",
        "32133123","32111123","33222233","33333333"])
    tiles[22]=tile_from_rows([
        "33322333","33233233","32333323","23311332",
        "23311332","32333323","33233233","33322333"])
    tiles[23]=tile_from_rows([
        "33333333","33221122","32112211","31122112",
        "32211221","32112211","33221122","33333333"])
    tiles[24]=tile_from_rows([
        "33333333","33322333","33211233","32133123",
        "32133123","33211233","33322333","33333333"])
    tiles[25]=tile_from_rows([
        "33333333","33222233","32133123","31322313",
        "31322313","32133123","33222233","33333333"])
    tiles[26]=tile_from_rows([
        "33322333","33322333","33211233","33211233",
        "33211233","33211233","33322333","33322333"])
    tiles[27]=tile_from_rows([
        "33333333","32222223","32121213","32121213",
        "32121213","32121213","32222223","33333333"])
    tiles[28]=tile_from_rows([
        "33333333","33332222","33223333","32233311",
        "32233311","33223333","33332222","33333333"])
    tiles[29]=tile_from_rows([
        "33333333","22223333","33332233","11333223",
        "11333223","33332233","22223333","33333333"])

    # UI plate tiles.
    tiles[30]=tile_from_rows([
        "33333333","32222222","32111111","32111111",
        "32111111","32111111","32222222","33333333"])
    tiles[31]=tile_from_rows([
        "33333333","22222223","11111123","11111123",
        "11111123","11111123","22222223","33333333"])

    # ASCII font at literal character code.
    for code in range(32,127):
        ch=chr(code).upper()
        if ch==' ': tiles[code]=blank()
        elif ch in FONT: tiles[code]=glyph_tile(ch)

    # Large 16x24 title glyphs (128-187).  Ten unique letters x six tiles.
    unique=[]
    for ch in "VOIDLANCER":
        if ch not in unique: unique.append(ch)
    mapping={}; idx=128
    for ch in unique:
        mapping[ch]=idx
        for q,t in enumerate(big_glyph_tiles(ch)): tiles[idx+q]=t
        idx+=6

    # Four-tile lance divider (188-191): a solid emblem, not a wire-frame rule.
    lance=[[0]*32 for _ in range(8)]
    for x in range(3,28):
        lance[3][x]=2; lance[4][x]=2
    for x in range(6,27): lance[2][x]=3
    for x in range(6,27): lance[5][x]=1
    for y,w in ((1,4),(2,3),(3,2),(4,2),(5,3),(6,4)):
        for x in range(w): lance[y][x]=1 if y>=4 else 2
    lance[2][27]=2; lance[3][28]=3; lance[3][29]=3; lance[4][28]=2; lance[4][29]=2
    lance[3][30]=3; lance[4][30]=2; lance[3][31]=2; lance[4][31]=1
    for i,bx in enumerate((0,8,16,24)):
        tiles[188+i]=[r[bx:bx+8] for r in lance]

    # 48x48 VOID CORE (192-227): concentric mass + dithered shell.  This is
    # deliberately an illustration, inspired by the large focal objects used
    # on late-80s/early-90s shooter title screens, not a bordered UI panel.
    orb=[[0]*48 for _ in range(48)]
    cx=cy=23.5
    for y in range(48):
        for x in range(48):
            dx=x-cx; dy=y-cy; d=(dx*dx+dy*dy)**0.5
            v=0
            if 21.0 < d <= 23.5:
                if ((x+y)&1)==0: v=1
            elif 17.0 < d <= 21.0: v=1
            elif 12.0 < d <= 17.0: v=2 if ((x-y)&3) else 3
            elif 8.0 < d <= 12.0: v=3
            elif 5.5 < d <= 8.0: v=2
            elif d <= 5.5: v=0
            if v and ((x*3+y*5)&31)==0: v=max(1,v-1)
            orb[y][x]=v
    ti=192
    for by in range(0,48,8):
        for bx in range(0,48,8):
            tiles[ti]=[r[bx:bx+8] for r in orb[by:by+8]]; ti+=1

    # 32x24 hero fighter silhouette for the title screen (228-239).
    hero=[
        "00000000000000330000000000000000",
        "00000000000002332000000000000000",
        "00000000000023333200000000000000",
        "00000000000233333320000000000000",
        "00000000002333223332000000000000",
        "00000000023332112333200000000000",
        "00000000233332222333320000000000",
        "00000002333333333333332000000000",
        "00000023333333333333333200000000",
        "00002333333332233333333332000000",
        "00233333333322223333333333320000",
        "02333333333221122333333333332000",
        "23333333332211112233333333333200",
        "02222233333223322333332222222000",
        "00000023333323323333333200000000",
        "00000002333333333333332000000000",
        "00000000233333333333320000000000",
        "00000000023332223333200000000000",
        "00000000002332223332000000000000",
        "00000000023330003333200000000000",
        "00000000233000000333320000000000",
        "00000002330000000033332000000000",
        "00000023000000000000333200000000",
        "00000020000000000000000200000000"]
    hc=[[int(ch) for ch in row] for row in hero]
    ti=228
    for by in (0,8,16):
        for bx in (0,8,16,24):
            tiles[ti]=[r[bx:bx+8] for r in hc[by:by+8]]; ti+=1

    # Title-only UI marks (240-242): a filled selector and compact A/B caps.
    tiles[240]=tile_from_rows([
        "00011000","00122100","01233210","12333321",
        "01233210","00122100","00011000","00000000"])
    tiles[241]=tile_from_rows([
        "00111100","01222210","12233221","12322321",
        "12333321","12322321","01222210","00111100"])
    tiles[242]=tile_from_rows([
        "00111100","01222210","12333221","12322321",
        "12333221","12322321","01222210","00111100"])

    # Extra stage texture vocabulary.  CHR-ROM is fixed at 4 KiB for BG, so
    # these deliberately occupy the few slots not consumed by fonts/title art.
    # 127 + 243..255 are all used in the scrolling stage nametables.
    tiles[127]=tile_from_rows([  # pebble / dust knot
        "00000000","00002000","00123200","01232100",
        "00121000","02000200","00000000","00010000"])
    tiles[243]=tile_from_rows([  # crater face
        "00122200","01233320","12321132","23211123",
        "23111123","12311232","01233320","00122200"])
    tiles[244]=tile_from_rows([  # fractured rock
        "00111000","01223100","12332210","23312321",
        "32123312","01233210","00122100","00011000"])
    tiles[245]=tile_from_rows([  # wreckage plate
        "00000000","00333320","03211230","32133210",
        "32111230","03233320","00322000","00000000"])
    tiles[246]=tile_from_rows([  # crystal shard
        "00030000","00323000","03233200","32323320",
        "23333210","02332100","00231000","00020000"])
    tiles[247]=tile_from_rows([  # riveted station plate
        "23333332","32222223","32111123","32133123",
        "32133123","32111123","32222223","23333332"])
    tiles[248]=tile_from_rows([  # louver / vent
        "33333333","32222223","33333333","32111123",
        "33333333","32222223","33333333","32111123"])
    tiles[249]=tile_from_rows([  # conduit junction
        "33322333","33322333","32211223","32133123",
        "32133123","32211223","33322333","33322333"])
    tiles[250]=tile_from_rows([  # hazard hatch
        "33333333","33221133","32112213","31221123",
        "32112213","31221123","33221133","33333333"])
    tiles[251]=tile_from_rows([  # reactor cell
        "33333333","33222233","32133123","31322313",
        "31322313","32133123","33222233","33333333"])
    tiles[252]=tile_from_rows([  # induction coil
        "33333333","33211233","32133123","31322313",
        "32133123","33211233","33322333","33333333"])
    tiles[253]=tile_from_rows([  # cable knot
        "33333333","33122333","31233213","12311321",
        "32133123","31233213","33122333","33333333"])
    tiles[254]=tile_from_rows([  # broken relay
        "33333333","33222233","32100323","31033013",
        "32300123","33222233","33322333","33333333"])
    tiles[255]=tile_from_rows([  # glowing port
        "33333333","33222233","32111123","32133123",
        "32133123","32111123","33222233","33333333"])

    return b''.join(encode_tile(t) for t in tiles),mapping

def canvas_to_tiles(c16):
    return [ [r[bx:bx+8] for r in c16[by:by+8]] for by in (0,8) for bx in (0,8) ]

def make_sprite_chr():
    tiles=[blank() for _ in range(256)]

    def place_canvas(start, canvas):
        h=len(canvas); w=len(canvas[0])
        assert h%8==0 and w%8==0 and all(len(r)==w for r in canvas)
        i=0
        for by in range(0,h,8):
            for bx in range(0,w,8):
                tiles[start+i]=[r[bx:bx+8] for r in canvas[by:by+8]]
                i+=1
        return start+i

    def cv(w=16,h=16): return [[0]*w for _ in range(h)]
    def px(c,x,y,v):
        if 0<=y<len(c) and 0<=x<len(c[0]): c[y][x]=v
    def rect(c,x0,y0,x1,y1,v):
        for y in range(y0,y1+1):
            for x in range(x0,x1+1): px(c,x,y,v)
    def hline(c,x0,x1,y,v):
        for x in range(x0,x1+1): px(c,x,y,v)
    def vline(c,x,y0,y1,v):
        for y in range(y0,y1+1): px(c,x,y,v)
    def ring(c,cx,cy,r0,r1,v):
        for y in range(len(c)):
            for x in range(len(c[0])):
                d=(x-cx)*(x-cx)+(y-cy)*(y-cy)
                if r0*r0 <= d <= r1*r1: c[y][x]=v

    # ------------------------------------------------------------------
    # Core player / projectiles / legacy small actors.
    # ------------------------------------------------------------------
    player=[
        "0000000330000000","0000002332000000","0000023333200000","0000023223200000",
        "0000233333320000","0002333223332000","0233333333333320","2333333333333332",
        "0222223333222220","0000233333320000","0000033333300000","0000033223300000",
        "0000233223320000","0002303223032000","0023002112003200","0200000110000020"]
    pc=[[int(ch) for ch in row] for row in player]
    for i,t in enumerate(canvas_to_tiles(pc)): tiles[i]=t

    tiles[4]=tile_from_rows([
        "00011000","00133100","00133100","00133100",
        "00133100","00133100","00022000","00011000"])
    tiles[5]=tile_from_rows([
        "00011000","00133100","01333310","13322331",
        "33333333","03322330","00300300","02000020"])
    tiles[6]=tile_from_rows([
        "02000020","23211232","33322333","33233233",
        "33333333","23322332","02333320","20011002"])
    tiles[7]=tile_from_rows([
        "00011000","00122100","01233210","12333321",
        "12333321","01233210","00122100","00011000"])
    tiles[8]=tile_from_rows([
        "00011000","00133100","01322310","13233231",
        "13233231","01322310","00133100","00011000"])
    tiles[9]=tile_from_rows([
        "20000002","32011023","23322332","33233233",
        "33333333","03333330","30300303","23000032"])
    tiles[10]=tile_from_rows([
        "00010000","01030100","00333000","13333331",
        "00333000","01030100","00010000","00000000"])
    tiles[11]=tile_from_rows([
        "10000001","03011030","00322300","13333331",
        "13333331","00322300","03011030","10000001"])
    tiles[12]=tile_from_rows([
        "00030000","00323000","03233200","32333320",
        "23333330","02333200","00232000","00020000"])
    tiles[13]=tile_from_rows([
        "00000000","00011000","00122100","00133100",
        "00122100","00033000","00022000","00010000"])
    tiles[14]=tile_from_rows([
        "00000000","00011000","00133100","00122100",
        "00133100","00022000","00033000","00010000"])
    tiles[15]=tile_from_rows([  # impact flash
        "10000001","01011010","00133100","11333311",
        "11333311","00133100","01011010","10000001"])

    # 32x24 boss carrier, tiles 16..27.
    boss=[
        "00000000000033333300000000000000","00000000000233333320000000000000",
        "00000000002333223332000000000000","00000000023332112333200000000000",
        "00000002333332222333332000000000","00000233333333333333333320000000",
        "00023333333332233333333333200000","02333333333321123333333333332000",
        "23333333333213312333333333333200","33333322222133331222223333333330",
        "33333211112333223321111233333330","33332123333333333333212333333330",
        "33321233333330033333321233333330","33332123333333333333212333333330",
        "33333211112333223321111233333330","33333322222133331222223333333330",
        "23333333333213312333333333333200","02333333333321123333333333332000",
        "00023333333332233333333333200000","00000233333333333333333320000000",
        "00000002333332222333332000000000","00000000023330003333200000000000",
        "00000000233000000333320000000000","00000002330000000033332000000000"]
    bc=[[int(ch) for ch in row] for row in boss]
    place_canvas(16,bc)

    # Boss module / damage overlays, tiles 28..39 (three 16x16 modules).
    for module,start in ((0,28),(1,32),(2,36)):
        c=cv()
        if module==0:  # exposed core
            ring(c,7.5,7.5,3.2,6.3,2); ring(c,7.5,7.5,0.0,3.0,3)
            for y in range(4,12):
                px(c,2,y,1); px(c,13,y,1)
        elif module==1:  # cannon housing
            rect(c,2,3,13,12,2); rect(c,4,5,11,10,1); rect(c,6,0,9,7,3)
            px(c,3,4,3); px(c,12,4,3); px(c,3,11,3); px(c,12,11,3)
        else:  # fractured armor
            rect(c,1,2,14,13,2); rect(c,3,4,12,11,1)
            for i in range(8): px(c,4+i,4+i//2,3)
            for i in range(7): px(c,10-i,8+i//2,0)
        place_canvas(start,c)

    # Legacy 8x8 alternate actors kept for compatibility/debugging.
    tiles[40]=tile_from_rows([
        "00011000","00333300","03322330","33333333",
        "13333331","00322300","03000030","30000003"])
    tiles[41]=tile_from_rows([
        "20000002","33211233","33322333","23333232",
        "33333333","33222333","02333320","02011020"])
    tiles[42]=tile_from_rows([
        "30000003","23011032","33322333","23333232",
        "33333333","03333330","20300302","32000023"])

    # Enemy projectile language now varies by stage, 43..47.
    tiles[43]=tile_from_rows([  # Dust Belt shard
        "00000000","00030000","00323000","03233200",
        "00323000","00032000","00002000","00000000"])
    tiles[44]=tile_from_rows([  # Neon Orbit ring laser
        "00000000","00122100","01200210","12033012",
        "12033012","01200210","00122100","00000000"])
    tiles[45]=tile_from_rows([  # Core Relay spark
        "00010000","00131000","01323100","13233210",
        "01323100","00131000","00010000","00000000"])
    tiles[46]=tile_from_rows([  # Boss heavy orb A
        "00122100","01233210","12333321","23311332",
        "23311332","12333321","01233210","00122100"])
    tiles[47]=tile_from_rows([  # Boss heavy orb B
        "00011000","01233210","12311321","23133132",
        "23133132","12311321","01233210","00011000"])

    # Threat meter, 48..55.
    for n in range(8):
        t=blank()
        for y in range(1,7):
            t[y][0]=2; t[y][7]=2
        t[0]=[0,2,2,2,2,2,2,0]; t[7]=[0,2,2,2,2,2,2,0]
        for i in range(n):
            x=1+i%6; y=2+(i//6)*3
            if x<7:
                t[y][x]=3; t[min(6,y+1)][x]=3
        tiles[48+n]=t

    # Animated power crystal, 56..59.
    power_frames=[
        ["00011000","00133100","01322310","13233231","13233231","01322310","00133100","00011000"],
        ["00001000","00023100","00322310","03233231","32332310","03223100","00321000","00010000"],
        ["00000000","00111000","01233100","12322310","03233231","00322310","00023100","00001000"],
        ["00010000","00123000","01322300","13233230","01323323","00132230","00013200","00001000"],
    ]
    for i,rows in enumerate(power_frames): tiles[56+i]=tile_from_rows(rows)

    # Player weapon bolts, 60..63.  The level-3 pair has a wider core.
    tiles[60]=tile_from_rows([
        "00011000","00133100","00133100","00133100","00133100","00133100","00022000","00011000"])
    tiles[61]=tile_from_rows([
        "00122100","01233210","01233210","01233210","01233210","01233210","00122100","00011000"])
    tiles[62]=tile_from_rows([
        "01133110","12333321","12333321","12333321","12333321","12333321","01233210","00122100"])
    tiles[63]=tile_from_rows([
        "10000001","01011010","00133100","01333310","01333310","00133100","01011010","10000001"])

    # Sprite HUD digits 64..73.
    for d in range(10): tiles[64+d]=glyph_tile(str(d))

    # Compact HUD icons, 74..80.
    tiles[74]=tile_from_rows([
        "00033000","00333300","03322330","33333333",
        "03333330","00322300","00022000","00011000"])
    for level,idx in enumerate((75,76,77),1):
        t=blank(); xs={1:[3,4],2:[1,2,5,6],3:[0,1,3,4,6,7]}[level]
        for x in xs:
            for y in range(1,7): t[y][x]=3 if 2<=y<=4 else 2
        tiles[idx]=t
    tiles[78]=tile_from_rows(["03333330","03222230","03233230","03233230","03233230","03233230","03222230","03333330"])
    tiles[79]=tile_from_rows(["03333330","03222230","03003330","00333230","03332030","03230030","03222230","03333330"])
    tiles[80]=tile_from_rows(["03333330","03222230","03000330","00333230","03000330","03222230","03222230","03333330"])

    # Extra HUD/status vocabulary 81..95: shield, heat, core, lock, medals and
    # tiny faction emblems. These are available to future UI without redrawing CHR.
    extras=[
        ["00122100","01233210","12311321","23100132","23100132","12311321","01233210","00122100"],
        ["00033000","00333300","03211230","32133123","32133123","03211230","00333300","00033000"],
        ["00011000","00133100","01322310","13233231","13233231","01322310","00133100","00011000"],
        ["10000001","01022010","00133100","02333320","02333320","00133100","01022010","10000001"],
        ["00033000","00322300","03211230","32133123","03211230","00322300","00033000","00000000"],
        ["00111100","01222210","12333321","12311321","12333321","01222210","00111100","00000000"],
        ["00030000","00323000","03233200","32323320","23333210","02332100","00231000","00020000"],
        ["03000030","32300323","23233232","02333320","02333320","23233232","32300323","03000030"],
        ["00122100","01211210","12133121","21333312","21333312","12133121","01211210","00122100"],
        ["00011000","00122100","01233210","12311321","12311321","01233210","00122100","00011000"],
        ["00000000","03300330","32211223","23133132","23133132","32211223","03300330","00000000"],
        ["00030000","00333000","03323300","33211233","33211233","03323300","00333000","00030000"],
        ["00300300","03213230","32133123","21333312","32133123","03213230","00300300","00000000"],
        ["00122100","01233210","12322321","23233232","12322321","01233210","00122100","00000000"],
        ["00011000","00333300","03222230","32133123","32133123","03222230","00333300","00011000"],
    ]
    for i,rows in enumerate(extras): tiles[81+i]=tile_from_rows(rows)

    # ------------------------------------------------------------------
    # Stage-specific 16x16 enemies, 96..167.
    # Each type gets two animation frames (4 tiles each):
    #   stage 1: 96..119, stage 2: 120..143, stage 3: 144..167.
    # ------------------------------------------------------------------
    def enemy_canvas(stage,kind,frame):
        c=cv()
        if stage==1 and kind==1:  # Razor mite / stone dart
            widths=[1,1,2,2,3,4,6,7,7,6,5,4,3]
            for y,w in enumerate(widths):
                x0=8-w; x1=7+w
                for x in range(x0,x1+1):
                    v=3 if y<5 else (2 if ((x+y)&2)==0 else 1)
                    px(c,x,y,v)
            rect(c,6,5,9,10,3); rect(c,7,6,8,8,1)
            if frame==0:
                px(c,1,8,3); px(c,14,8,3); px(c,3,10,2); px(c,12,10,2)
            else:
                px(c,0,9,2); px(c,15,9,2); px(c,2,11,3); px(c,13,11,3)
            px(c,5,13,2); px(c,10,13,2); px(c,4,14,1); px(c,11,14,1); px(c,3,15,1); px(c,12,15,1)
        elif stage==1 and kind==2:  # Crag gunner
            for y in range(2,14):
                for x in range(1,15):
                    dx=x-7.5; dy=y-7.5
                    d=dx*dx/42+dy*dy/30
                    if d<=1:
                        c[y][x]=2 if ((x*3+y)&3) else 1
            rect(c,4,4,11,11,3); rect(c,6,5,9,10,1)
            rect(c,7,0,8,6,3 if frame==0 else 2)
            px(c,2,5,3); px(c,13,5,3); px(c,2,10,3); px(c,13,10,3)
            if frame: px(c,1,7,2); px(c,14,8,2)
        elif stage==1 and kind==3:  # Dust eye / crescent seeker
            ring(c,7.5,7.5,4.0,6.8,2)
            rect(c,4,6,11,9,1); rect(c,6,6,9,9,3)
            px(c,7,7,0); px(c,8,7,0)
            for x,y in [(1,4),(14,4),(0,7),(15,7),(2,12),(13,12)]: px(c,x,y,3)
            if frame==0:
                px(c,3,13,2); px(c,12,13,2); px(c,4,15,1); px(c,11,15,1)
            else:
                px(c,2,14,2); px(c,13,14,2); px(c,5,15,1); px(c,10,15,1)
        elif stage==2 and kind==1:  # Neon interceptor
            vline(c,7,0,14,3); vline(c,8,0,14,3); rect(c,6,3,9,10,2)
            for i in range(6):
                px(c,5-i,5+i,2); px(c,10+i,5+i,2)
                if i<4: px(c,5-i,6+i,3); px(c,10+i,6+i,3)
            rect(c,7,5,8,8,1)
            if frame==0:
                px(c,2,10,1); px(c,13,10,1); px(c,5,14,2); px(c,10,14,2)
            else:
                px(c,1,11,3); px(c,14,11,3); px(c,6,15,2); px(c,9,15,2)
        elif stage==2 and kind==2:  # Station turret pod
            rect(c,1,3,14,13,2); rect(c,3,5,12,11,1); rect(c,5,6,10,10,3)
            rect(c,7,0,8,7,3 if frame==0 else 2)
            for x,y in [(1,3),(14,3),(1,13),(14,13),(3,5),(12,5)]: px(c,x,y,3)
            if frame: rect(c,0,7,2,9,2); rect(c,13,7,15,9,2)
        elif stage==2 and kind==3:  # Ring sentinel
            ring(c,7.5,7.5,4.2,6.8,2); ring(c,7.5,7.5,1.0,3.1,3)
            for x,y in [(7,0),(8,0),(7,15),(8,15),(0,7),(0,8),(15,7),(15,8)]: px(c,x,y,3)
            if frame==0:
                px(c,2,2,1); px(c,13,13,1); px(c,13,2,2); px(c,2,13,2)
            else:
                px(c,3,1,2); px(c,12,14,2); px(c,14,3,1); px(c,1,12,1)
        elif stage==3 and kind==1:  # Void spear
            rect(c,7,0,8,15,3); rect(c,6,3,9,11,2); rect(c,7,5,8,8,1)
            for i in range(6):
                px(c,6-i,6+i,2 if i<3 else 1); px(c,9+i,6+i,2 if i<3 else 1)
            if frame==0:
                px(c,1,11,3); px(c,14,11,3); px(c,4,14,2); px(c,11,14,2)
            else:
                px(c,0,12,2); px(c,15,12,2); px(c,3,15,3); px(c,12,15,3)
        elif stage==3 and kind==2:  # Armored core beetle
            for y in range(2,14):
                w=4+min(y,15-y)//2
                for x in range(8-w,8+w): px(c,x,y,2)
            rect(c,4,4,11,12,1); ring(c,7.5,7.5,0.0,3.4,3)
            for x,y in [(1,4),(14,4),(0,7),(15,7),(1,11),(14,11)]: px(c,x,y,3 if frame==0 else 2)
            px(c,7,7,1); px(c,8,7,1)
        else:  # stage 3 seeker: void eye with tentacles
            ring(c,7.5,6.5,3.0,6.0,2); rect(c,4,5,11,8,1); rect(c,6,5,9,8,3)
            px(c,7,6,0); px(c,8,6,0)
            tent=[(2,10),(1,12),(0,14),(5,11),(4,13),(3,15),(10,11),(11,13),(12,15),(13,10),(14,12),(15,14)]
            for j,(x,y) in enumerate(tent): px(c,x,y,3 if (j+frame)%2==0 else 2)
        return c

    starts={1:96,2:120,3:144}
    for st in (1,2,3):
        base=starts[st]
        for kind in (1,2,3):
            for fr in (0,1):
                place_canvas(base+(kind-1)*8+fr*4, enemy_canvas(st,kind,fr))

    # 16x16 explosion / impact animation, six frames, 168..191.
    for fr in range(6):
        c=cv(); radius=1.8+fr*1.25
        for y in range(16):
            for x in range(16):
                dx=x-7.5; dy=y-7.5; d=(dx*dx+dy*dy)**0.5
                if abs(d-radius)<1.0: c[y][x]=3
                elif abs(d-radius)<2.1 and ((x+y+fr)&1)==0: c[y][x]=2
                elif d<radius and ((x*3+y*5+fr)&7)==0: c[y][x]=1
        # asymmetrical sparks make the blast feel hand-authored, not a circle.
        for x,y in [(7,0),(15,6),(1,12),(12,15),(3,3),(13,2)]:
            if (x+y+fr)%3==0: px(c,x,y,3)
        place_canvas(168+fr*4,c)

    # Weapon/effect tiles, 192..207 (four 16x16 effects).
    effects=[]
    for kind in range(4):
        c=cv()
        if kind==0:  # pulse wave
            ring(c,7.5,7.5,4.0,6.8,2); ring(c,7.5,7.5,1.0,3.0,3)
        elif kind==1:  # lock reticle
            hline(c,1,5,2,3); hline(c,10,14,2,3); hline(c,1,5,13,3); hline(c,10,14,13,3)
            vline(c,2,1,5,3); vline(c,13,1,5,3); vline(c,2,10,14,3); vline(c,13,10,14,3)
            ring(c,7.5,7.5,2.0,3.5,2)
        elif kind==2:  # shield flare
            for y in range(1,15):
                xoff=abs(8-y)//2
                px(c,2+xoff,y,2); px(c,13-xoff,y,2)
            ring(c,7.5,7.5,4.0,6.0,1)
        else:  # charge bloom
            for i in range(8):
                px(c,7,i,2); px(c,8,15-i,2); px(c,i,7,3); px(c,15-i,8,3)
            ring(c,7.5,7.5,1.0,3.0,3)
        effects.append(c)
        place_canvas(192+kind*4,c)

    # Boss modular art, 208..231 (six 16x16 components).
    for kind in range(6):
        c=cv()
        if kind==0:  # rotary cannon
            rect(c,2,4,13,11,2); rect(c,5,5,10,10,1); rect(c,7,0,8,7,3); rect(c,4,12,11,14,1)
        elif kind==1:  # missile rack
            rect(c,1,2,14,13,2)
            for yy in (4,9):
                for xx in (4,11): ring(c,xx,yy,0,2.0,3)
        elif kind==2:  # shield node
            ring(c,7.5,7.5,3.0,6.8,2); ring(c,7.5,7.5,0.0,2.5,3)
        elif kind==3:  # engine cluster
            rect(c,2,2,13,9,2)
            for xx in (4,8,12):
                rect(c,xx-1,7,xx,14,3); px(c,xx-1,15,1); px(c,xx,15,1)
        elif kind==4:  # damaged armor
            rect(c,1,1,14,14,2); rect(c,3,3,12,12,1)
            for x,y in [(3,3),(4,4),(5,5),(6,6),(7,7),(8,7),(9,8),(10,9),(11,10)]: px(c,x,y,0)
            for x,y in [(6,3),(9,5),(4,10),(12,12)]: px(c,x,y,3)
        else:  # void core eye
            ring(c,7.5,7.5,4.0,6.8,1); ring(c,7.5,7.5,2.0,4.0,2); rect(c,6,6,9,9,3)
        place_canvas(208+kind*4,c)

    # Future special-enemy set, 232..255 (six 16x16 actors).  Keeping these in
    # CHR makes the OSS atlas useful for extending stages without new art first.
    for kind in range(6):
        c=cv()
        if kind==0:  # spinner
            ring(c,7.5,7.5,2.0,4.5,3)
            for i in range(7): px(c,7-i,7-i,2); px(c,8+i,7-i,2); px(c,7-i,8+i,1); px(c,8+i,8+i,1)
        elif kind==1:  # mine
            ring(c,7.5,7.5,2.5,5.0,2); rect(c,6,6,9,9,3)
            for x,y in [(7,0),(8,0),(7,15),(8,15),(0,7),(0,8),(15,7),(15,8)]: px(c,x,y,3)
        elif kind==2:  # relay satellite
            rect(c,6,2,9,13,2); rect(c,0,5,5,10,1); rect(c,10,5,15,10,1); rect(c,7,6,8,9,3)
        elif kind==3:  # mini carrier
            rect(c,2,5,13,11,2); rect(c,5,3,10,13,3); rect(c,6,6,9,9,1); px(c,0,8,2); px(c,15,8,2)
        elif kind==4:  # worm head
            ring(c,7.5,6.5,3.0,6.0,2); rect(c,4,5,11,9,3); px(c,6,6,0); px(c,9,6,0); rect(c,5,12,10,15,1)
        else:  # crystal knight
            for y,w in enumerate([1,2,3,4,5,6,7,7,6,5,4,3,2,1]):
                for x in range(8-w,8+w): px(c,x,y,3 if y<6 else 2)
            rect(c,6,5,9,10,1); px(c,3,12,3); px(c,12,12,3)
        place_canvas(232+kind*4,c)

    return b''.join(encode_tile(t) for t in tiles)

def blank_nt(fill=0): return [[fill]*32 for _ in range(30)]
def put_text(nt,row,col,text):
    for i,ch in enumerate(text):
        if 0<=row<30 and 0<=col+i<32: nt[row][col+i]=ord(ch.upper())
def put_big(nt,row,col,text,map_):
    x=col
    for ch in text:
        if ch==' ': x+=2; continue
        base=map_[ch]
        nt[row][x]=base; nt[row][x+1]=base+1
        nt[row+1][x]=base+2; nt[row+1][x+1]=base+3
        nt[row+2][x]=base+4; nt[row+2][x+1]=base+5
        x+=2

def attr_bytes(default=0, accent_rows=None):
    # Each byte controls 4x4 tiles. Use same palette for all four quadrants for simplicity.
    out=[]; accent_rows=accent_rows or {}
    for ay in range(8):
        for ax in range(8):
            p=accent_rows.get((ax,ay),default)&3
            out.append(p | (p<<2) | (p<<4) | (p<<6))
    return bytes(out)

def attr_bytes_16(pmap, default=0):
    """Encode a 16x16-pixel palette map at the PPU's real attribute granularity.

    pmap is 15 rows x 16 cols for the visible 256x240 area.  The old helper
    intentionally used one palette for all four quadrants of each attribute
    byte (32x32), which threw away half the title screen's color composition.
    """
    out=[]
    for ay in range(8):
        for ax in range(8):
            vals=[]
            for qy,qx in ((0,0),(0,1),(1,0),(1,1)):
                py=ay*2+qy; px=ax*2+qx
                vals.append((pmap[py][px] if py<len(pmap) and px<len(pmap[py]) else default)&3)
            tl,tr,bl,br=vals
            out.append(tl | (tr<<2) | (bl<<4) | (br<<6))
    return bytes(out)

def encode_nt(nt,attrs):
    flat=bytes(v&0xFF for row in nt for v in row)
    assert len(flat)==960 and len(attrs)==64
    return flat+attrs

def title_nt(mapping):
    nt=blank_nt(0)
    r=random.Random(0x1991)

    # Sparse stars are support texture only; the eye should land on large
    # filled forms, not on frames and one-pixel rules.
    for y in range(30):
        for x in range(32):
            v=r.random()
            if v<.025: nt[y][x]=1
            elif v<.031: nt[y][x]=2
            elif v<.047 and (x<8 or x>23): nt[y][x]=3

    # Dithered nebula masses in the corners.
    for cy,cx in [(12,2),(14,4),(22,27),(24,25),(5,2),(27,4)]:
        for yy in range(-1,2):
            for xx in range(-2,3):
                y=cy+yy; x=cx+xx
                if 0<=y<30 and 0<=x<32 and r.random()<.64:
                    nt[y][x]=4 if r.random()<.58 else 5

    # A couple of solid, irregular 16x16 asteroids anchor the lower field.
    for y,x in [(19,1),(25,28)]:
        nt[y][x]=7; nt[y][x+1]=8; nt[y+1][x]=9; nt[y+1][x+1]=10

    # VOID CORE illustration at top-right (48x48).
    ti=192
    for yy in range(6):
        for xx in range(6):
            nt[1+yy][25+xx]=ti; ti+=1

    # Main logo: 16x24 filled, beveled glyphs.  No border around the logo.
    put_big(nt,1,12,"VOID",mapping)
    for i,t in enumerate(range(188,192)): nt[4][14+i]=t
    put_big(nt,5,10,"LANCER",mapping)
    put_text(nt,9,7,"VOID SIGNAL DIVISION")

    # Hero craft and textured exhaust/debris.
    ti=228
    for yy in range(3):
        for xx in range(4):
            nt[11+yy][14+xx]=ti; ti+=1
    for y,x,t in [(14,15,6),(15,15,5),(16,15,4),(14,16,6),(15,16,4),
                  (13,12,3),(15,20,3),(16,9,11),(14,22,11)]:
        nt[y][x]=t

    # Minimal cartridge-era menu.  Custom filled cursor/button caps reduce the
    # feeling of a text-only terminal UI.
    nt[18][9]=240
    put_text(nt,18,11,"START")
    put_text(nt,20,11,"1 PLAYER")
    nt[23][8]=241; put_text(nt,23,10,"FIRE")
    nt[23][18]=242; put_text(nt,23,20,"PULSE")
    put_text(nt,27,8,"VOID SIGNAL // 01")

    # 16x16 palette zoning at the NES's real attribute granularity.
    pmap=[[3 for _ in range(16)] for _ in range(15)]
    for py in range(0,5):
        for px in range(4,12): pmap[py][px]=0   # warm logo
    for py in range(0,4):
        for px in range(12,16): pmap[py][px]=1  # cold void core
    for py in range(5,9):
        for px in range(4,12): pmap[py][px]=2   # hero band
    # Colored texture around the otherwise neutral menu zone.
    for py in range(4,15):
        for px in range(0,4): pmap[py][px]=1
        for px in range(12,16): pmap[py][px]=2
    return encode_nt(nt,attr_bytes_16(pmap,3))

def _scatter_stars(nt,r,rate=.04):
    for y in range(30):
        for x in range(32):
            v=r.random()
            if v<rate: nt[y][x]=1
            elif v<rate+.006: nt[y][x]=2
            elif v<rate+.018: nt[y][x]=3

def stage1_nt():
    nt=blank_nt(0); r=random.Random(101); _scatter_stars(nt,r,.032)
    # Dust Belt: broad nebula/dust masses plus several scales of rock debris.
    for cy,cx in [(5,5),(10,24),(17,8),(24,25),(27,13)]:
        for yy in range(-2,3):
            for xx in range(-3,4):
                y=cy+yy; x=cx+xx
                if 0<=y<30 and 0<=x<32:
                    d=abs(xx)+abs(yy)
                    if r.random() < max(.18,.82-d*.10): nt[y][x]=4 if r.random()<.60 else 5
    for y,x in [(3,3),(7,20),(13,10),(19,25),(24,2)]:
        nt[y][x]=7; nt[y][x+1]=8; nt[y+1][x]=9; nt[y+1][x+1]=10
    # Smaller foreground/background rock vocabulary.
    small=[127,243,244,245,246,11]
    for y,x in [(2,26),(5,15),(9,3),(11,29),(15,20),(18,5),(21,17),(26,8),(27,27),(13,25),(23,21)]:
        nt[y][x]=small[(x+y)%len(small)]
    # Color islands follow actual 16x16 clusters instead of one palette per 32x32 cell.
    pmap=[[0 for _ in range(16)] for _ in range(15)]
    for py,px in [(2,2),(4,10),(7,5),(10,12),(12,1),(5,12),(9,3),(13,7)]:
        for yy in range(max(0,py-1),min(15,py+2)):
            for xx in range(max(0,px-1),min(16,px+2)): pmap[yy][xx]=1
    return encode_nt(nt,attr_bytes_16(pmap,0))

def stage2_nt():
    nt=blank_nt(0); r=random.Random(202); _scatter_stars(nt,r,.010)
    # Neon Orbit: asymmetric station trench, vents, hatches and conduit nodes.
    for y in range(30):
        mod=[15,247,14,248][(y//3)%4]
        pipe=[16,249,18,250][(y//4)%4]
        left=[12,mod,pipe,19]
        right=[19,pipe,mod,13]
        for i,t in enumerate(left): nt[y][i]=t
        for i,t in enumerate(right): nt[y][28+i]=t
    # Occasional buttresses intrude into the flight lane.
    for y in (6,14,23):
        for x in range(4,8): nt[y][x]=17 if x%2 else 247
        for x in range(24,28): nt[y][x]=17 if x%2 else 248
    for y,x,t in [(4,8,249),(9,23,250),(12,6,247),(17,25,248),(21,9,249),(26,22,250)]: nt[y][x]=t
    for y,x in [(3,18),(11,13),(19,18),(27,11)]: nt[y][x]=6
    pmap=[[0 for _ in range(16)] for _ in range(15)]
    for py in range(15):
        for px in range(0,3): pmap[py][px]=1 if (py//2)%2==0 else 2
        for px in range(13,16): pmap[py][px]=2 if (py//2)%2==0 else 1
    for py,px in [(3,3),(7,12),(11,4),(13,11)]: pmap[py][px]=2
    return encode_nt(nt,attr_bytes_16(pmap,0))

def stage3_nt():
    nt=blank_nt(0); r=random.Random(303); _scatter_stars(nt,r,.004)
    # Core Relay: machinery walls now cycle through sockets, coils, broken relays
    # and glowing ports instead of repeating the same five tiles all screen long.
    left_variants=[251,252,253,254,255]
    for y in range(30):
        socket=[22,21,251,255][(y//3)%4]
        accent=left_variants[(y//2)%len(left_variants)]
        left=[20,accent,socket,26,27]
        right=[27,26,socket,accent,20]
        for i,t in enumerate(left): nt[y][i]=t
        for i,t in enumerate(right): nt[y][27+i]=t
    for y in (6,16,26):
        for x in range(5,12): nt[y][x]=23 if x%3 else 252
        for x in range(20,27): nt[y][x]=23 if x%3 else 253
        nt[y][12]=24; nt[y][19]=24
    for y,x,t in [(9,7,254),(9,23,255),(12,11,251),(20,8,252),(20,22,253),(24,19,254)]:
        nt[y][x]=t
    for y,x in [(10,7),(10,23),(21,8),(21,22)]: nt[y][x]=28; nt[y][x+1]=29
    pmap=[[0 for _ in range(16)] for _ in range(15)]
    for py in range(15):
        for px in range(0,4): pmap[py][px]=2 if (py//2)%2==0 else 1
        for px in range(12,16): pmap[py][px]=1 if (py//2)%2==0 else 2
    for py in (3,8,13):
        for px in range(4,12): pmap[py][px]=1
    return encode_nt(nt,attr_bytes_16(pmap,0))

def end_nt(win=False):
    nt=blank_nt(0); r=random.Random(404 if win else 405); _scatter_stars(nt,r,.055)
    # Large central status card.
    for y in range(8,18):
        nt[y][7]=30; nt[y][24]=31
    if win:
        put_text(nt,10,9,"CORE SILENCED")
        put_text(nt,13,7,"MISSION COMPLETE")
        put_text(nt,15,9,"VOID IS QUIET")
    else:
        put_text(nt,10,10,"LANCER LOST")
        put_text(nt,13,9,"SIGNAL DEAD")
        put_text(nt,15,8,"RETRY THE VOID")
    put_text(nt,20,10,"PRESS START")
    put_text(nt,23,9,"FINAL SCORE")
    return encode_nt(nt,attr_bytes(0,{(2,2):1,(3,2):1,(4,2):1,(5,2):1}))

def ppm_preview(bgchr,sprchr,path):
    # 32x16 tile contact sheet: BG top half, sprite bottom half.
    palette=[(8,12,20),(80,112,160),(80,220,224),(244,244,220)]
    w,h=128,256
    px=[palette[0]]*(w*h)
    def decode(data,idx):
        off=idx*16; p0=data[off:off+8]; p1=data[off+8:off+16]
        t=[]
        for y in range(8):
            row=[]
            for x in range(8):
                b=7-x; row.append(((p0[y]>>b)&1)|(((p1[y]>>b)&1)<<1))
            t.append(row)
        return t
    for bank,data,yoff in [(0,bgchr,0),(1,sprchr,128)]:
        for idx in range(256):
            tx=(idx%16)*8; ty=(idx//16)*8+yoff
            t=decode(data,idx)
            for y in range(8):
                for x in range(8): px[(ty+y)*w+tx+x]=palette[t[y][x]]
    with path.open('wb') as f:
        f.write(f'P6\n{w} {h}\n255\n'.encode())
        for r,g,b in px: f.write(bytes((r,g,b)))

def main():
    bg,mapping=make_bg_chr(); sp=make_sprite_chr(); chrdata=bg+sp
    (AS/'chr.bin').write_bytes(chrdata)
    (AS/'title.nam').write_bytes(title_nt(mapping))
    (AS/'stage1.nam').write_bytes(stage1_nt())
    (AS/'stage2.nam').write_bytes(stage2_nt())
    (AS/'stage3.nam').write_bytes(stage3_nt())
    (AS/'gameover.nam').write_bytes(end_nt(False))
    (AS/'win.nam').write_bytes(end_nt(True))
    print('generated CHR + nametables')
if __name__=='__main__': main()
