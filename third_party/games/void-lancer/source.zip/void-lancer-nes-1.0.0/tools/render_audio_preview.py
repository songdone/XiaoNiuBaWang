#!/usr/bin/env python3
"""Render an approximate desktop WAV preview of VOID LANCER's 2A03 music data.

This is intentionally a lightweight audition tool, not a cycle-accurate NES APU
emulator. The ROM itself remains the authoritative playback target.
"""
from __future__ import annotations
from pathlib import Path
import argparse, math, random, re, struct, wave

ROOT=Path(__file__).resolve().parents[1]
ASM=ROOT/'src'/'main.asm'
TRACKS=[('title','Signal in the Void'),('stage1','Vector Burn'),('stage2','Glass Orbit'),('core','Core Relay'),('boss','Black Star Engine'),('win','Afterburn Glow')]
NOTE_NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
SPEEDS=[6,5,5,4,4,7]
# DD values from the actual engine tables, mapped to duty fraction.
LEAD_A=[1,1,2,0,1,2]; LEAD_B=[2,0,3,2,0,1]
HARM_A=[0,2,1,3,0,1]; HARM_B=[1,3,0,1,2,2]
DUTY=[0.125,0.25,0.5,0.75]


def parse_array(src:str,label:str):
    m=re.search(rf'^%s:\s*$' % re.escape(label),src,re.M)
    if not m: raise KeyError(label)
    tail=src[m.end():]
    vals=[]
    for line in tail.splitlines():
        if re.match(r'^[A-Za-z_][\w]*:\s*$',line.strip()): break
        line=line.split(';',1)[0].strip()
        if not line.startswith('.byte'): continue
        for tok in line[5:].split(','):
            tok=tok.strip()
            if not tok: continue
            vals.append(int(tok[1:],16) if tok.startswith('$') else int(tok))
    return vals


def freq(idx:int)->float:
    if idx<=0: return 0.0
    semitone=idx-1
    octave=2+semitone//12
    note=semitone%12
    midi=12*(octave+1)+note
    return 440.0*2**((midi-69)/12)


def pulse(phase:float,duty:float)->float:
    return 1.0 if phase<duty else -1.0

def tri(phase:float)->float:
    # -1..+1 triangle
    return 4.0*abs(phase-0.5)-1.0


def render_track(src:str,key:str,mode:int,sr:int=44100):
    mel=parse_array(src,f'melody_{key}')
    harm=parse_array(src,f'harmony_{key}')
    bass=parse_array(src,f'bass_{key}')
    drums=parse_array(src,f'drums_{key}')
    assert len(mel)==len(harm)==len(bass)==len(drums)==128
    step_sec=SPEEDS[mode]/60.0
    nstep=max(1,int(round(step_sec*sr)))
    out=[]
    p1=p2=pt=0.0
    rng=random.Random(0x564F4944 + mode)
    for st in range(128):
        f1,f2,ft=map(freq,(mel[st],harm[st],bass[st]))
        d1=DUTY[(LEAD_B if st&8 else LEAD_A)[mode]]
        d2=DUTY[(HARM_B if st&4 else HARM_A)[mode]]
        drum=drums[st]
        for i in range(nstep):
            x=i/nstep
            # Mimic the ROM's short per-step pulse decay.
            e1=(1.0-0.55*x) if f1 else 0.0
            e2=(0.62-0.30*x) if f2 else 0.0
            y=0.0
            if f1:
                vib=1.0 + (0.0012*math.sin(2*math.pi*7.2*(i/sr)))
                p1=(p1+f1*vib/sr)%1.0
                y += 0.32*e1*pulse(p1,d1)
            if f2:
                p2=(p2+f2/sr)%1.0
                y += 0.22*e2*pulse(p2,d2)
            if ft:
                pt=(pt+ft/sr)%1.0
                y += 0.26*tri(pt)
            # Approximate APU noise events with distinct decay/filter character.
            if drum:
                if drum==1 and x<0.34:
                    env=(1-x/0.34)**2
                    bit=1.0 if ((i*17 + st*13)&16) else -1.0
                    y += 0.12*env*bit
                elif drum==2 and x<0.55:
                    env=(1-x/0.55)**2
                    y += 0.20*env*(rng.random()*2-1)
                elif drum==3 and x<0.48:
                    env=(1-x/0.48)**2
                    low=math.sin(2*math.pi*(85-45*x)*(i/sr))
                    y += 0.24*env*(0.65*low+0.35*(rng.random()*2-1))
                elif drum==4 and x<0.9:
                    env=(1-x/0.9)**1.5
                    y += 0.23*env*(rng.random()*2-1)
            # soft clip
            y=math.tanh(y*1.25)*0.82
            out.append(int(max(-1,min(1,y))*32767))
    return out


def write_wav(path:Path,samples,sr=44100):
    path.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes(b''.join(struct.pack('<h',v) for v in samples))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('-o','--output',type=Path,default=ROOT/'build'/'soundtrack-preview.wav')
    ap.add_argument('--split-dir',type=Path)
    args=ap.parse_args()
    src=ASM.read_text()
    sr=44100
    combined=[]
    silence=[0]*sr
    for mode,(key,title) in enumerate(TRACKS):
        samples=render_track(src,key,mode,sr)
        if args.split_dir:
            write_wav(args.split_dir/f'{mode+1:02d}-{key}.wav',samples,sr)
        combined.extend(samples); combined.extend(silence)
        print(f'{title}: {len(samples)/sr:.2f}s')
    write_wav(args.output,combined,sr)
    print('wrote',args.output, f'{len(combined)/sr:.2f}s')

if __name__=='__main__': main()
