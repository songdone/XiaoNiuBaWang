#!/usr/bin/env python3
"""Tiny dependency-free 6502 assembler for VOID LANCER.

Supported directives: .org, .byte, .word, .incbin
Supported syntax is intentionally small but conventional.
Conditional branches are emitted as a safe long-branch sequence
(inverse branch + JMP), so branch distance is never a build hazard.
"""
from __future__ import annotations
import argparse, ast, re
from pathlib import Path

OP = {
    'ADC': {'imm':0x69,'zp':0x65,'zpx':0x75,'abs':0x6D,'absx':0x7D,'absy':0x79,'indx':0x61,'indy':0x71},
    'AND': {'imm':0x29,'zp':0x25,'zpx':0x35,'abs':0x2D,'absx':0x3D,'absy':0x39,'indx':0x21,'indy':0x31},
    'ASL': {'acc':0x0A,'zp':0x06,'zpx':0x16,'abs':0x0E,'absx':0x1E},
    'BIT': {'zp':0x24,'abs':0x2C},
    'BRK': {'imp':0x00},
    'CLC': {'imp':0x18}, 'CLD': {'imp':0xD8}, 'CLI': {'imp':0x58}, 'CLV': {'imp':0xB8},
    'CMP': {'imm':0xC9,'zp':0xC5,'zpx':0xD5,'abs':0xCD,'absx':0xDD,'absy':0xD9,'indx':0xC1,'indy':0xD1},
    'CPX': {'imm':0xE0,'zp':0xE4,'abs':0xEC},
    'CPY': {'imm':0xC0,'zp':0xC4,'abs':0xCC},
    'DEC': {'zp':0xC6,'zpx':0xD6,'abs':0xCE,'absx':0xDE},
    'DEX': {'imp':0xCA}, 'DEY': {'imp':0x88},
    'EOR': {'imm':0x49,'zp':0x45,'zpx':0x55,'abs':0x4D,'absx':0x5D,'absy':0x59,'indx':0x41,'indy':0x51},
    'INC': {'zp':0xE6,'zpx':0xF6,'abs':0xEE,'absx':0xFE},
    'INX': {'imp':0xE8}, 'INY': {'imp':0xC8},
    'JMP': {'abs':0x4C,'ind':0x6C}, 'JSR': {'abs':0x20},
    'LDA': {'imm':0xA9,'zp':0xA5,'zpx':0xB5,'abs':0xAD,'absx':0xBD,'absy':0xB9,'indx':0xA1,'indy':0xB1},
    'LDX': {'imm':0xA2,'zp':0xA6,'zpy':0xB6,'abs':0xAE,'absy':0xBE},
    'LDY': {'imm':0xA0,'zp':0xA4,'zpx':0xB4,'abs':0xAC,'absx':0xBC},
    'LSR': {'acc':0x4A,'zp':0x46,'zpx':0x56,'abs':0x4E,'absx':0x5E},
    'NOP': {'imp':0xEA},
    'ORA': {'imm':0x09,'zp':0x05,'zpx':0x15,'abs':0x0D,'absx':0x1D,'absy':0x19,'indx':0x01,'indy':0x11},
    'PHA': {'imp':0x48}, 'PHP': {'imp':0x08}, 'PLA': {'imp':0x68}, 'PLP': {'imp':0x28},
    'ROL': {'acc':0x2A,'zp':0x26,'zpx':0x36,'abs':0x2E,'absx':0x3E},
    'ROR': {'acc':0x6A,'zp':0x66,'zpx':0x76,'abs':0x6E,'absx':0x7E},
    'RTI': {'imp':0x40}, 'RTS': {'imp':0x60},
    'SBC': {'imm':0xE9,'zp':0xE5,'zpx':0xF5,'abs':0xED,'absx':0xFD,'absy':0xF9,'indx':0xE1,'indy':0xF1},
    'SEC': {'imp':0x38}, 'SED': {'imp':0xF8}, 'SEI': {'imp':0x78},
    'STA': {'zp':0x85,'zpx':0x95,'abs':0x8D,'absx':0x9D,'absy':0x99,'indx':0x81,'indy':0x91},
    'STX': {'zp':0x86,'zpy':0x96,'abs':0x8E}, 'STY': {'zp':0x84,'zpx':0x94,'abs':0x8C},
    'TAX': {'imp':0xAA}, 'TAY': {'imp':0xA8}, 'TSX': {'imp':0xBA},
    'TXA': {'imp':0x8A}, 'TXS': {'imp':0x9A}, 'TYA': {'imp':0x98},
}
BRANCH = {'BCC':0x90,'BCS':0xB0,'BEQ':0xF0,'BMI':0x30,'BNE':0xD0,'BPL':0x10,'BVC':0x50,'BVS':0x70}
INV = {'BCC':'BCS','BCS':'BCC','BEQ':'BNE','BNE':'BEQ','BMI':'BPL','BPL':'BMI','BVC':'BVS','BVS':'BVC'}
MODE_SIZE = {'imp':1,'acc':1,'imm':2,'zp':2,'zpx':2,'zpy':2,'indx':2,'indy':2,'abs':3,'absx':3,'absy':3,'ind':3}

class ExprError(Exception): pass

def _replace_nums(s:str)->str:
    s = re.sub(r'\$([0-9A-Fa-f]+)', lambda m:'0x'+m.group(1), s)
    s = re.sub(r'(?<![\w])%([01]+)', lambda m:'0b'+m.group(1), s)
    return s

def eval_expr(expr:str, symbols:dict[str,int]) -> int:
    expr = expr.strip()
    lohi = None
    if expr.startswith('<'):
        lohi='lo'; expr=expr[1:].strip()
    elif expr.startswith('>'):
        lohi='hi'; expr=expr[1:].strip()
    expr = _replace_nums(expr)
    try:
        node = ast.parse(expr, mode='eval')
    except SyntaxError as e:
        raise ExprError(str(e))
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value,(int,str)):
            if isinstance(n.value,str):
                if len(n.value)!=1: raise ExprError('only one-char literals in expressions')
                return ord(n.value)
            return int(n.value)
        if isinstance(n, ast.Name):
            if n.id not in symbols: raise ExprError(f'unknown symbol {n.id}')
            return symbols[n.id]
        if isinstance(n, ast.UnaryOp):
            v=ev(n.operand)
            if isinstance(n.op, ast.USub): return -v
            if isinstance(n.op, ast.UAdd): return v
            if isinstance(n.op, ast.Invert): return ~v
        if isinstance(n, ast.BinOp):
            a,b=ev(n.left),ev(n.right)
            if isinstance(n.op, ast.Add): return a+b
            if isinstance(n.op, ast.Sub): return a-b
            if isinstance(n.op, ast.Mult): return a*b
            if isinstance(n.op, ast.FloorDiv): return a//b
            if isinstance(n.op, ast.Mod): return a%b
            if isinstance(n.op, ast.LShift): return a<<b
            if isinstance(n.op, ast.RShift): return a>>b
            if isinstance(n.op, ast.BitOr): return a|b
            if isinstance(n.op, ast.BitAnd): return a&b
            if isinstance(n.op, ast.BitXor): return a^b
        raise ExprError(f'unsupported expression: {ast.dump(n)}')
    v=ev(node)
    if lohi=='lo': v &= 0xFF
    elif lohi=='hi': v = (v>>8)&0xFF
    return v

def split_args(s:str):
    out=[]; cur=''; quote=None; esc=False; depth=0
    for ch in s:
        if esc:
            cur+=ch; esc=False; continue
        if ch=='\\' and quote:
            cur+=ch; esc=True; continue
        if quote:
            cur+=ch
            if ch==quote: quote=None
            continue
        if ch in ('"',"'"):
            quote=ch; cur+=ch; continue
        if ch=='(':
            depth+=1
        elif ch==')': depth-=1
        if ch==',' and depth==0:
            out.append(cur.strip()); cur=''
        else: cur+=ch
    if cur.strip() or s.endswith(','): out.append(cur.strip())
    return out

def strip_comment(line:str)->str:
    quote=None
    for i,ch in enumerate(line):
        if ch in ('"',"'"):
            quote = None if quote==ch else (ch if quote is None else quote)
        elif ch==';' and quote is None:
            return line[:i]
    return line

class Assembler:
    def __init__(self, source:Path, origin_min=0x8000, origin_max=0x10000):
        self.source=source; self.base=source.parent.parent
        self.lines=source.read_text(encoding='utf-8').splitlines()
        self.sym={}; self.origin_min=origin_min; self.origin_max=origin_max

    def parse_mode(self, op:str, operand:str, allow_unresolved:bool):
        operand=operand.strip()
        if not operand: return 'imp',None
        if operand.upper()=='A': return 'acc',None
        if operand.startswith('#'): return 'imm', operand[1:].strip()
        m=re.fullmatch(r'\((.+)\),\s*[Yy]', operand)
        if m: return 'indy',m.group(1).strip()
        m=re.fullmatch(r'\((.+),\s*[Xx]\)', operand)
        if m: return 'indx',m.group(1).strip()
        m=re.fullmatch(r'\((.+)\)', operand)
        if m: return 'ind',m.group(1).strip()
        idx=None; expr=operand
        m=re.fullmatch(r'(.+),\s*([XxYy])', operand)
        if m:
            expr=m.group(1).strip(); idx=m.group(2).upper()
        val=None
        try: val=eval_expr(expr,self.sym)
        except ExprError:
            if not allow_unresolved: raise
        modes=OP.get(op,{})
        if idx=='X':
            if val is not None and 0<=val<256 and 'zpx' in modes: return 'zpx',expr
            return 'absx',expr
        if idx=='Y':
            if val is not None and 0<=val<256 and 'zpy' in modes: return 'zpy',expr
            return 'absy',expr
        if val is not None and 0<=val<256 and 'zp' in modes: return 'zp',expr
        return 'abs',expr

    def item_size(self,line:str,pc:int):
        s=strip_comment(line).strip()
        if not s: return 0,pc
        if ':' in s:
            label,rest=s.split(':',1); label=label.strip()
            if label:
                if label in self.sym and self.sym[label]!=pc: raise ValueError(f'duplicate label {label}')
                self.sym[label]=pc
            s=rest.strip()
            if not s: return 0,pc
        m=re.fullmatch(r'([A-Za-z_][\w]*)\s*=\s*(.+)',s)
        if m:
            self.sym[m.group(1)] = eval_expr(m.group(2),self.sym)
            return 0,pc
        if s.lower().startswith('.org'):
            return 0, eval_expr(s[4:].strip(),self.sym)
        if s.lower().startswith('.byte'):
            n=0
            for a in split_args(s[5:].strip()):
                if len(a)>=2 and a[0]==a[-1]=='"': n+=len(ast.literal_eval(a).encode('ascii'))
                else: n+=1
            return n,pc+n
        if s.lower().startswith('.word'):
            n=2*len(split_args(s[5:].strip())); return n,pc+n
        if s.lower().startswith('.incbin'):
            q=s[7:].strip(); path=ast.literal_eval(q)
            p=(self.base/path).resolve(); n=p.stat().st_size; return n,pc+n
        parts=s.split(None,1); op=parts[0].upper(); operand=parts[1] if len(parts)>1 else ''
        if op in BRANCH: return 5,pc+5
        if op not in OP: raise ValueError(f'unknown opcode/directive: {op}')
        mode,_=self.parse_mode(op,operand,True)
        if mode not in OP[op]: raise ValueError(f'{op} does not support {mode}: {operand}')
        n=MODE_SIZE[mode]; return n,pc+n

    def first_pass(self):
        pc=self.origin_min
        # Up to 3 passes so constant chains and labels settle.
        for _ in range(3):
            pc=self.origin_min
            for lineno,line in enumerate(self.lines,1):
                try: _,pc=self.item_size(line,pc)
                except Exception as e: raise RuntimeError(f'{self.source}:{lineno}: {e}') from e
        return pc

    def assemble(self)->bytes:
        self.first_pass()
        mem=bytearray([0xFF]*(self.origin_max-self.origin_min)); pc=self.origin_min
        def emit(b:int):
            nonlocal pc
            if not (self.origin_min<=pc<self.origin_max): raise ValueError(f'PC out of range {pc:04X}')
            mem[pc-self.origin_min]=b&0xFF; pc+=1
        for lineno,line in enumerate(self.lines,1):
            raw=line; s=strip_comment(line).strip()
            if not s: continue
            if ':' in s:
                _,s=s.split(':',1); s=s.strip()
                if not s: continue
            if re.fullmatch(r'([A-Za-z_][\w]*)\s*=\s*(.+)',s): continue
            try:
                if s.lower().startswith('.org'):
                    pc=eval_expr(s[4:].strip(),self.sym); continue
                if s.lower().startswith('.byte'):
                    for a in split_args(s[5:].strip()):
                        if len(a)>=2 and a[0]==a[-1]=='"':
                            for b in ast.literal_eval(a).encode('ascii'): emit(b)
                        else: emit(eval_expr(a,self.sym))
                    continue
                if s.lower().startswith('.word'):
                    for a in split_args(s[5:].strip()):
                        v=eval_expr(a,self.sym); emit(v); emit(v>>8)
                    continue
                if s.lower().startswith('.incbin'):
                    path=ast.literal_eval(s[7:].strip()); data=(self.base/path).read_bytes()
                    for b in data: emit(b)
                    continue
                parts=s.split(None,1); op=parts[0].upper(); operand=parts[1] if len(parts)>1 else ''
                if op in BRANCH:
                    target=eval_expr(operand,self.sym)
                    emit(BRANCH[INV[op]]); emit(3); emit(OP['JMP']['abs']); emit(target); emit(target>>8)
                    continue
                mode,expr=self.parse_mode(op,operand,False); emit(OP[op][mode])
                if MODE_SIZE[mode]==1: continue
                v=eval_expr(expr,self.sym)
                emit(v)
                if MODE_SIZE[mode]==3: emit(v>>8)
            except Exception as e:
                raise RuntimeError(f'{self.source}:{lineno}: {raw}\n  {e}') from e
        return bytes(mem)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('source',type=Path); ap.add_argument('-o','--output',type=Path,required=True)
    args=ap.parse_args(); asm=Assembler(args.source); data=asm.assemble(); args.output.parent.mkdir(parents=True,exist_ok=True); args.output.write_bytes(data)
    print(f'assembled {args.source} -> {args.output} ({len(data)} bytes)')
if __name__=='__main__': main()
