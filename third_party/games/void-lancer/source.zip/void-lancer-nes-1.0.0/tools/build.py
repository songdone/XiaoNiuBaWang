#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'; BUILD=ROOT/'build'; SRC=ROOT/'src'/'main.asm'

def run(*args):
    print('+', ' '.join(map(str,args)))
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True)

def main():
    BUILD.mkdir(exist_ok=True)
    run(sys.executable, ROOT/'tools'/'gen_assets.py')
    run(sys.executable, ROOT/'tools'/'asm6502.py', SRC, '-o', BUILD/'prg.bin')
    prg=(BUILD/'prg.bin').read_bytes(); chrdata=(ASSETS/'chr.bin').read_bytes()
    assert len(prg)==32768, len(prg)
    assert len(chrdata)==8192, len(chrdata)
    # iNES 1.0: 2x16KiB PRG, 1x8KiB CHR, mapper 0, vertical mirroring.
    header=bytes([0x4E,0x45,0x53,0x1A, 2,1, 0x01,0x00, 0,0,0,0,0,0,0,0])
    rom=header+prg+chrdata
    out=BUILD/'void-lancer.nes'; out.write_bytes(rom)
    reset=int.from_bytes(prg[0x7FFC:0x7FFE],'little')
    nmi=int.from_bytes(prg[0x7FFA:0x7FFC],'little')
    irq=int.from_bytes(prg[0x7FFE:0x8000],'little')
    assert 0x8000 <= reset <= 0xFFF9
    assert 0x8000 <= nmi <= 0xFFF9
    assert 0x8000 <= irq <= 0xFFF9
    sha=hashlib.sha256(rom).hexdigest()
    (BUILD/'SHA256SUMS.txt').write_text(f'{sha}  void-lancer.nes\n',encoding='ascii')
    print(f'Built {out} ({len(rom)} bytes)')
    print(f'  NMI=${nmi:04X} RESET=${reset:04X} IRQ=${irq:04X}')
    print(f'  SHA256 {sha}')
if __name__=='__main__': main()
