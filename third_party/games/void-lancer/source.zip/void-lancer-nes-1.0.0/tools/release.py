#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"
DIST = ROOT / "dist"
VERSION_FILE = ROOT / "VERSION"


def run(*args: object) -> None:
    print("+", " ".join(map(str, args)))
    subprocess.run([str(x) for x in args], cwd=ROOT, check=True)


def normalize_version(raw: str) -> str:
    raw = raw.strip().lower()
    if raw.startswith("v"):
        raw = raw[1:]
    if re.fullmatch(r"\d+\.\d+", raw):
        raw += ".0"
    if not re.fullmatch(r"\d+\.\d+\.\d+", raw):
        raise SystemExit("version must look like 1.0, 1.0.0, v1.0, or v1.0.0")
    return raw


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def include_in_source(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    blocked = {".git", "build", "dist", "__pycache__", ".pytest_cache"}
    return not any(part in blocked for part in rel.parts)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build/test/package a VOID LANCER release.")
    parser.add_argument("version", nargs="?", help="release version, e.g. 1.0.0 or v1.0")
    args = parser.parse_args()

    requested = normalize_version(args.version) if args.version else normalize_version(VERSION_FILE.read_text())
    declared = normalize_version(VERSION_FILE.read_text())
    if requested != declared:
        raise SystemExit(f"VERSION says {declared}; update VERSION before packaging {requested}")

    tag = f"v{requested}"
    run(sys.executable, ROOT / "tools" / "build.py")
    run(sys.executable, ROOT / "tools" / "music_test.py")
    run(sys.executable, ROOT / "tools" / "smoke_test.py")

    DIST.mkdir(exist_ok=True)
    for old in DIST.glob("VOID-LANCER-*"):
        if old.is_file():
            old.unlink()

    rom_src = BUILD / "void-lancer.nes"
    rom_dst = DIST / f"VOID-LANCER-{tag}.nes"
    shutil.copy2(rom_src, rom_dst)

    source_zip = DIST / f"VOID-LANCER-{tag}-source.zip"
    with zipfile.ZipFile(source_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(ROOT.rglob("*")):
            if path.is_file() and include_in_source(path):
                zf.write(path, Path("void-lancer-nes") / path.relative_to(ROOT))

    sums = DIST / f"VOID-LANCER-{tag}-SHA256SUMS.txt"
    sums.write_text(
        f"{sha256(rom_dst)}  {rom_dst.name}\n"
        f"{sha256(source_zip)}  {source_zip.name}\n",
        encoding="ascii",
    )

    print("\nRelease ready:")
    print(f"  {rom_dst}")
    print(f"  {source_zip}")
    print(f"  {sums}")


if __name__ == "__main__":
    main()
