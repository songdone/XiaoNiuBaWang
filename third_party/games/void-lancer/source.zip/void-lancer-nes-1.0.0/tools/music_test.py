#!/usr/bin/env python3
"""Static validation for the original 2A03 soundtrack data."""
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
src=(ROOT/'src'/'main.asm').read_text()
TRACKS=['title','stage1','stage2','core','boss','win']

def arr(label):
    m=re.search(rf'^{re.escape(label)}:\s*$',src,re.M)
    assert m, label
    vals=[]
    for line in src[m.end():].splitlines():
        if re.match(r'^[A-Za-z_][\w]*:\s*$',line.strip()): break
        line=line.split(';',1)[0].strip()
        if not line.startswith('.byte'): continue
        for t in line[5:].split(','):
            t=t.strip()
            if t: vals.append(int(t[1:],16) if t.startswith('$') else int(t))
    return vals

for t in TRACKS:
    for stem in ('melody','harmony','bass','drums'):
        v=arr(f'{stem}_{t}')
        assert len(v)==128,(t,stem,len(v))
        if stem=='drums': assert all(0<=x<=4 for x in v),(t,stem)
        else: assert all(0<=x<=48 for x in v),(t,stem)
assert len(arr('pulse_period_lo'))==48
assert len(arr('pulse_period_hi'))==48
assert len(arr('tri_period_lo'))==48
assert len(arr('tri_period_hi'))==48
assert arr('music_speed_table')==[6,5,5,4,4,7]
print('music ok: 6 songs x 128 steps, chromatic C2-B5 tables, drum events valid')
