#!/usr/bin/env python3
from pathlib import Path
import struct,zlib
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'assets'; OUT=ROOT/'docs'/'screenshots'; OUT.mkdir(parents=True,exist_ok=True)
chrdata=(A/'chr.bin').read_bytes()
# Approximate common NTSC NES palette (RGB), enough for repository previews.
NES=[
(84,84,84),(0,30,116),(8,16,144),(48,0,136),(68,0,100),(92,0,48),(84,4,0),(60,24,0),(32,42,0),(8,58,0),(0,64,0),(0,60,0),(0,50,60),(0,0,0),(0,0,0),(0,0,0),
(152,150,152),(8,76,196),(48,50,236),(92,30,228),(136,20,176),(160,20,100),(152,34,32),(120,60,0),(84,90,0),(40,114,0),(8,124,0),(0,118,40),(0,102,120),(0,0,0),(0,0,0),(0,0,0),
(236,238,236),(76,154,236),(120,124,236),(176,98,236),(228,84,236),(236,88,180),(236,106,100),(212,136,32),(160,170,0),(116,196,0),(76,208,32),(56,204,108),(56,180,204),(60,60,60),(0,0,0),(0,0,0),
(236,238,236),(168,204,236),(188,188,236),(212,178,236),(236,174,236),(236,174,212),(236,180,176),(228,196,144),(204,210,120),(180,222,120),(168,226,144),(152,226,180),(160,214,228),(160,162,160),(0,0,0),(0,0,0)]

def dec_tile(bank,idx):
    off=bank*4096+idx*16; p0=chrdata[off:off+8]; p1=chrdata[off+8:off+16]
    return [[((p0[y]>>(7-x))&1)|(((p1[y]>>(7-x))&1)<<1) for x in range(8)] for y in range(8)]
def write_png(path,w,h,pix,scale=1):
    if scale!=1:
        p2=[]
        for y in range(h):
            row=pix[y*w:(y+1)*w]
            rr=[]
            for c in row: rr.extend([c]*scale)
            for _ in range(scale): p2.extend(rr)
        pix=p2; w*=scale; h*=scale
    raw=b''.join(b'\x00'+b''.join(bytes(c) for c in pix[y*w:(y+1)*w]) for y in range(h))
    def chunk(t,d): return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
    data=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw,9))+chunk(b'IEND',b'')
    path.write_bytes(data)
def render_bg(nam,pal):
    nt=nam[:960]; attrs=nam[960:1024]; pix=[NES[pal[0]]]*(256*240)
    for ty in range(30):
        for tx in range(32):
            tile=dec_tile(0,nt[ty*32+tx]); ab=attrs[(ty//4)*8+(tx//4)]
            shift=((ty%4)//2)*4+((tx%4)//2)*2; pi=(ab>>shift)&3
            for yy in range(8):
                for xx in range(8):
                    v=tile[yy][xx]; ci=pal[0] if v==0 else pal[pi*4+v]
                    pix[(ty*8+yy)*256+tx*8+xx]=NES[ci&0x3f]
    return pix
def sprite(pix,x,y,tile,pal,palid=0,flipx=False,flipy=False):
    t=dec_tile(1,tile)
    for yy in range(8):
        for xx in range(8):
            sx=7-xx if flipx else xx; sy=7-yy if flipy else yy; v=t[sy][sx]
            if not v: continue
            px=x+xx; py=y+yy
            if 0<=px<256 and 0<=py<240: pix[py*256+px]=NES[pal[16+palid*4+v]&0x3f]
def sprite16(pix,x,y,base,pal,palid=0):
    sprite(pix,x,y,base,pal,palid)
    sprite(pix,x+8,y,base+1,pal,palid)
    sprite(pix,x,y+8,base+2,pal,palid)
    sprite(pix,x+8,y+8,base+3,pal,palid)

def getpal(name):
    # Mirrors palettes from main.asm for preview.
    pals={
      'title':[0x0F,0x06,0x17,0x27,0x0F,0x01,0x12,0x31,0x0F,0x03,0x13,0x2C,0x0F,0x00,0x10,0x30,
               0x0F,0x0C,0x2C,0x30,0x0F,0x06,0x16,0x27,0x0F,0x17,0x28,0x30,0x0F,0x03,0x13,0x30],
      's1':[0x0F,0x01,0x11,0x21,0x0F,0x07,0x17,0x27,0x0F,0x03,0x13,0x23,0x0F,0x00,0x10,0x30,
            0x0F,0x0C,0x2C,0x30,0x0F,0x06,0x16,0x27,0x0F,0x17,0x28,0x30,0x0F,0x03,0x13,0x30],
      's2':[0x0F,0x03,0x13,0x23,0x0F,0x0C,0x1C,0x2C,0x0F,0x04,0x14,0x24,0x0F,0x00,0x10,0x30,
            0x0F,0x0C,0x2C,0x30,0x0F,0x05,0x15,0x25,0x0F,0x17,0x28,0x30,0x0F,0x03,0x13,0x30],
      's3':[0x0F,0x06,0x16,0x27,0x0F,0x07,0x17,0x28,0x0F,0x03,0x13,0x23,0x0F,0x00,0x10,0x30,
            0x0F,0x0C,0x2C,0x30,0x0F,0x06,0x16,0x27,0x0F,0x17,0x28,0x30,0x0F,0x03,0x13,0x30]}
    return pals[name]

def add_mock_hud(pix,pal,stage=2,weapon=2,threat=5,lives=3,bombs=2):
    for i,d in enumerate([0,0,0,8,0,0]): sprite(pix,8+i*8,8,64+d,pal,3)
    sprite(pix,64,8,74+weapon,pal,2)
    sprite(pix,76,8,77+stage,pal,1)
    for i in range(lives): sprite(pix,8+i*10,20,74,pal,0)
    for i in range(bombs): sprite(pix,222-i*10,20,12,pal,2)
    sprite(pix,120,20,48+threat,pal,1)

def add_mock_player_and_enemies(pix,pal,stage=2,boss=False):
    # Player 16x16 + animated exhaust.
    for x,y,t,p in [(120,198,0,0),(128,198,1,0),(120,206,2,0),(128,206,3,0),(124,212,13,2)]:
        sprite(pix,x,y,t,pal,p)
    if boss:
        t=16
        for yy in range(3):
            for xx in range(4):
                sprite(pix,96+xx*8,54+yy*8,t,pal,1); t+=1
    else:
        stage_base={1:96,2:120,3:144}[stage]
        # Two frames are mixed in the mock screen so the atlas visibly shows motion variety.
        enemies=[(42,62,stage_base+0),(176,82,stage_base+8),(102,112,stage_base+16),
                 (206,48,stage_base+4),(24,132,stage_base+12)]
        for x,y,t in enemies: sprite16(pix,x,y,t,pal,1)
    # Player bolts, biome-specific enemy bolts and power crystal.
    eb={1:43,2:44,3:45}[stage]
    for x,y,t,p in [(124,168,61 if stage>1 else 60,2),(124,150,62 if stage>1 else 60,2),
                    (58,108,eb,1),(184,130,eb,1),(112,84,56,2)]: sprite(pix,x,y,t,pal,p)

def render_chr_sheet(path):
    # Raw CHR contact sheet: BG bank left, sprite bank right, 16x16 tiles each.
    palrgb=[(8,12,20),(80,112,160),(80,220,224),(244,244,220)]
    w,h=256,128
    pix=[palrgb[0]]*(w*h)
    for bank in (0,1):
        xoff=bank*128
        for idx in range(256):
            t=dec_tile(bank,idx); tx=xoff+(idx%16)*8; ty=(idx//16)*8
            for yy in range(8):
                for xx in range(8): pix[(ty+yy)*w+tx+xx]=palrgb[t[yy][xx]]
    write_png(path,w,h,pix,3)

def render_art_atlas(path):
    # Curated assembled sprite atlas, useful because raw CHR splits every 16x16 actor into 8x8 tiles.
    pal=getpal('s2'); bg=NES[0x0F]
    w,h=256,176; pix=[bg]*(w*h)
    # player and stage enemy rows
    for x,y,t,p in [(16,16,0,0),(24,16,1,0),(16,24,2,0),(24,24,3,0)]: sprite(pix,x,y,t,pal,p)
    for st,yy in ((1,48),(2,80),(3,112)):
        p2=getpal(f's{st}')
        base={1:96,2:120,3:144}[st]
        for k in range(3):
            sprite16(pix,16+k*36,yy,base+k*8,p2,1)
            sprite16(pix,32+k*36,yy,base+k*8+4,p2,1)
    # boss and selected modules/effects
    p3=getpal('s3'); t=16
    for by in range(3):
        for bx in range(4): sprite(pix,150+bx*8,16+by*8,t,p3,1); t+=1
    for i,base in enumerate((168,172,176,180,184,188)):
        sprite16(pix,142+(i%3)*36,64+(i//3)*36,base,p3,1)
    for i,base in enumerate((208,212,216,220,224,228)):
        sprite16(pix,142+(i%3)*36,136,base,p3,1)
    write_png(path,w,h,pix,3)

def main():
    pal=getpal('title')
    pix=render_bg((A/'title.nam').read_bytes(),pal)
    write_png(OUT/'title.png',256,240,pix,3)

    for key,file,stage,boss in [('s1','stage1.nam',1,False),('s2','stage2.nam',2,False),('s3','stage3.nam',3,True)]:
        pal=getpal(key); pix=render_bg((A/file).read_bytes(),pal)
        add_mock_player_and_enemies(pix,pal,stage=stage,boss=boss)
        add_mock_hud(pix,pal,stage=stage,weapon=2 if stage>1 else 1,threat=6 if boss else 4)
        name='gameplay.png' if key=='s2' else f'gameplay-{key}.png'
        write_png(OUT/name,256,240,pix,3)
    render_chr_sheet(A/'tiles.png')
    render_art_atlas(A/'art-atlas.png')
    print('rendered previews + CHR sheets')

if __name__=='__main__': main()
