#!/usr/bin/env python3
"""Small control-flow smoke test for the generated ROM.
Not a cycle-accurate NES emulator; it executes the 6502 game code with stubbed PPU/APU
registers and scripted controller input to catch bad opcodes, addresses and stack flow.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from asm6502 import OP, BRANCH, Assembler

ROOT=Path(__file__).resolve().parents[1]
rom=(ROOT/'build'/'void-lancer.nes').read_bytes()
assert rom[:4]==b'NES\x1a'
prg=rom[16:16+32768]
asm=Assembler(ROOT/'src'/'main.asm'); asm.first_pass(); WAIT_LOOP=asm.sym['wait_frame_loop']

rev={}
for name,modes in OP.items():
    for mode,opc in modes.items(): rev[opc]=(name,mode)
for name,opc in BRANCH.items(): rev[opc]=(name,'rel')

C=1; Z=2; I=4; D=8; B=16; U=32; V=64; N=128
class CPU:
    def __init__(self):
        self.ram=bytearray(0x8000); self.a=0; self.x=0; self.y=0; self.sp=0xFD; self.p=U|I
        self.pc=self.read16(0xFFFC); self.steps=0; self.frames=0; self.joy_i=8; self.joy_bits=[0]*8; self.strobe=0
    def read(self,a):
        a&=0xFFFF
        if a>=0x8000: return prg[a-0x8000]
        if a==0x2002: return 0x80
        if a==0x4016:
            if self.strobe: return self.pad_for_frame()>>7 & 1
            if self.joy_i<8:
                v=self.joy_bits[self.joy_i]; self.joy_i+=1; return v
            return 1
        if a<0x2000: return self.ram[a&0x7FF]
        return self.ram[a]
    def write(self,a,v):
        a&=0xFFFF; v&=0xFF
        if a>=0x8000: return
        if a==0x4016:
            old=self.strobe; self.strobe=v&1
            if old and not self.strobe:
                p=self.pad_for_frame()
                self.joy_bits=[1 if p&b else 0 for b in (0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01)]
                self.joy_i=0
            return
        if a<0x2000: self.ram[a&0x7FF]=v
        else: self.ram[a]=v
    def pad_for_frame(self):
        # Start once, then move/fire for gameplay, bomb once later.
        f=self.frames
        if 4<=f<=5: return 0x10
        if 10<=f<2800:
            p=0x80
            if f==80: p|=0x40
            return p
        return 0
    def read16(self,a): return self.read(a)|(self.read((a+1)&0xFFFF)<<8)
    def push(self,v): self.write(0x100+self.sp,v); self.sp=(self.sp-1)&0xFF
    def pull(self): self.sp=(self.sp+1)&0xFF; return self.read(0x100+self.sp)
    def setnz(self,v):
        v&=0xFF; self.p=(self.p & ~(N|Z)) | (Z if v==0 else 0) | (N if v&0x80 else 0); return v
    def addr(self,mode):
        if mode=='zp': a=self.read(self.pc); self.pc+=1; return a
        if mode=='zpx': a=(self.read(self.pc)+self.x)&0xFF; self.pc+=1; return a
        if mode=='zpy': a=(self.read(self.pc)+self.y)&0xFF; self.pc+=1; return a
        if mode=='abs': a=self.read16(self.pc); self.pc+=2; return a
        if mode=='absx': a=(self.read16(self.pc)+self.x)&0xFFFF; self.pc+=2; return a
        if mode=='absy': a=(self.read16(self.pc)+self.y)&0xFFFF; self.pc+=2; return a
        if mode=='indx':
            z=(self.read(self.pc)+self.x)&0xFF; self.pc+=1; return self.read(z)|(self.read((z+1)&0xFF)<<8)
        if mode=='indy':
            z=self.read(self.pc); self.pc+=1; return ((self.read(z)|(self.read((z+1)&0xFF)<<8))+self.y)&0xFFFF
        if mode=='ind':
            a=self.read16(self.pc); self.pc+=2; return self.read(a)|(self.read((a&0xFF00)|((a+1)&0xFF))<<8)
        raise RuntimeError(mode)
    def operand(self,mode):
        if mode=='imm': v=self.read(self.pc); self.pc+=1; return v,None
        a=self.addr(mode); return self.read(a),a
    def step(self):
        # The real game waits on nmi_count once per frame. When the test CPU reaches
        # that compare loop, simulate one NMI tick immediately.
        self.steps+=1
        if self.pc==WAIT_LOOP and (self.ram[0x2000] & 0x80):
            self.frames+=1
            self.ram[0x21]=(self.ram[0x21]+1)&0xFF
            if self.ram[0x00]==1:
                self.ram[0x0C]=200  # keep the scripted run alive to exercise stage transitions
        pc0=self.pc; opc=self.read(self.pc); self.pc=(self.pc+1)&0xFFFF
        if opc not in rev: raise RuntimeError(f'unknown opcode {opc:02X} at {pc0:04X}')
        op,mode=rev[opc]
        if mode=='rel':
            off=self.read(self.pc); self.pc+=1
            if off&0x80: off-=256
            take={'BCC':not(self.p&C),'BCS':bool(self.p&C),'BEQ':bool(self.p&Z),'BNE':not(self.p&Z),'BMI':bool(self.p&N),'BPL':not(self.p&N),'BVC':not(self.p&V),'BVS':bool(self.p&V)}[op]
            if take: self.pc=(self.pc+off)&0xFFFF
            return
        if op=='LDA': v,_=self.operand(mode); self.a=self.setnz(v)
        elif op=='LDX': v,_=self.operand(mode); self.x=self.setnz(v)
        elif op=='LDY': v,_=self.operand(mode); self.y=self.setnz(v)
        elif op in ('STA','STX','STY'):
            a=self.addr(mode); self.write(a, {'STA':self.a,'STX':self.x,'STY':self.y}[op])
        elif op in ('ADC','SBC'):
            v,_=self.operand(mode); old=self.a; cin=1 if self.p&C else 0
            if op=='ADC':
                s=old+v+cin; res=s&255; c=s>255; ov=(~(old^v)&(old^res)&0x80)!=0
            else:
                s=old-v-(1-cin); res=s&255; c=s>=0; ov=((old^v)&(old^res)&0x80)!=0
            self.a=self.setnz(res); self.p=(self.p&~(C|V))|(C if c else 0)|(V if ov else 0)
        elif op in ('AND','ORA','EOR'):
            v,_=self.operand(mode)
            self.a=self.setnz(self.a&v if op=='AND' else self.a|v if op=='ORA' else self.a^v)
        elif op in ('CMP','CPX','CPY'):
            v,_=self.operand(mode); r={'CMP':self.a,'CPX':self.x,'CPY':self.y}[op]; d=(r-v)&255
            self.p=(self.p&~(C|Z|N))|(C if r>=v else 0)|(Z if r==v else 0)|(N if d&128 else 0)
        elif op=='BIT':
            v,_=self.operand(mode); self.p=(self.p&~(Z|N|V))|(Z if (self.a&v)==0 else 0)|(v&(N|V))
        elif op in ('INC','DEC'):
            _,a=self.operand(mode); v=(self.read(a)+(1 if op=='INC' else -1))&255; self.write(a,v); self.setnz(v)
        elif op in ('INX','DEX','INY','DEY'):
            if op=='INX': self.x=self.setnz(self.x+1)
            elif op=='DEX': self.x=self.setnz(self.x-1)
            elif op=='INY': self.y=self.setnz(self.y+1)
            else: self.y=self.setnz(self.y-1)
        elif op in ('ASL','LSR','ROL','ROR'):
            if mode=='acc': v=self.a; a=None
            else: v,a=self.operand(mode)
            oldc=1 if self.p&C else 0
            if op=='ASL': c=v>>7; v=(v<<1)&255
            elif op=='LSR': c=v&1; v>>=1
            elif op=='ROL': c=v>>7; v=((v<<1)|oldc)&255
            else: c=v&1; v=((v>>1)|(oldc<<7))&255
            self.p=(self.p&~C)|(C if c else 0); self.setnz(v)
            if a is None: self.a=v
            else: self.write(a,v)
        elif op=='JMP': self.pc=self.addr(mode)
        elif op=='JSR':
            a=self.addr(mode); ret=(self.pc-1)&0xFFFF; self.push(ret>>8); self.push(ret); self.pc=a
        elif op=='RTS': self.pc=(((self.pull()|(self.pull()<<8))+1)&0xFFFF)
        elif op=='RTI': self.p=self.pull(); self.pc=self.pull()|(self.pull()<<8)
        elif op=='PHA': self.push(self.a)
        elif op=='PLA': self.a=self.setnz(self.pull())
        elif op=='PHP': self.push(self.p|B|U)
        elif op=='PLP': self.p=self.pull()|U
        elif op=='TAX': self.x=self.setnz(self.a)
        elif op=='TAY': self.y=self.setnz(self.a)
        elif op=='TXA': self.a=self.setnz(self.x)
        elif op=='TYA': self.a=self.setnz(self.y)
        elif op=='TSX': self.x=self.setnz(self.sp)
        elif op=='TXS': self.sp=self.x
        elif op=='CLC': self.p&=~C
        elif op=='SEC': self.p|=C
        elif op=='CLI': self.p&=~I
        elif op=='SEI': self.p|=I
        elif op=='CLD': self.p&=~D
        elif op=='SED': self.p|=D
        elif op=='CLV': self.p&=~V
        elif op=='NOP': pass
        elif op=='BRK': raise RuntimeError(f'BRK reached at {pc0:04X}')
        else: raise RuntimeError(f'unimplemented {op}/{mode} at {pc0:04X}')

cpu=CPU()
for _ in range(12000000):
    cpu.step()
    if cpu.frames>2650: break
assert cpu.frames>2500
assert cpu.ram[0x00] in (1,3), f'state={cpu.ram[0]}'
assert cpu.ram[0x0D] == 3, f'stage={cpu.ram[0x0D]}'
print(f'smoke ok: frames={cpu.frames} state={cpu.ram[0]} stage={cpu.ram[0x0D]} boss={cpu.ram[0x1E]} stage_timer={cpu.ram[0x0F]:02X}{cpu.ram[0x0E]:02X} score={list(cpu.ram[0x30:0x36])} lives={cpu.ram[0x0A]}')
