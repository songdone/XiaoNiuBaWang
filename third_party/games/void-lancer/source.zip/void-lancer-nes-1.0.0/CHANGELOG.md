# Changelog

## 1.0.0

First public release of **VOID LANCER**.

- Three-stage vertical shooter plus final boss for NES/Famicom mapper 0 / NROM-256.
- Custom illustrated title screen and expanded 8 KiB CHR art set.
- Stage-specific 16x16 enemy sprites, effects, boss modules, HUD icons, and scenery tiles.
- Six-track original 2A03 soundtrack with a 128-step music engine, per-song tempo, pulse-duty animation, envelopes, vibrato, and authored Noise drums.
- Power-ups, Pulse bombs, score/lives HUD, adaptive Threat gauge, Game Over, and Mission Complete states.
- Self-contained Python build chain, static music validation, CPU smoke tests, preview generation, and GitHub Actions release workflow.
- MIT licensed source suitable for public GitHub release.
