# Technical Notes

## Cartridge format

VOID LANCER emits an iNES 1.0 ROM with:

- 2 × 16 KiB PRG banks = 32 KiB
- 1 × 8 KiB CHR bank = 8 KiB
- Mapper 0
- Vertical mirroring flag
- No trainer
- No battery RAM

Final ROM size is 40,976 bytes: 16-byte iNES header + 32,768-byte PRG + 8,192-byte CHR.

## PRG layout

The custom assembler maps source directly into `$8000-$FFFF` and fills unused bytes with `$FF`.

```text
$8000 ... code, tables, palettes, embedded nametables
...
$FFFA NMI vector
$FFFC RESET vector
$FFFE IRQ vector
```

## RAM layout

```text
$0000-$0035  zero-page state, controller, score, audio state
$0200-$02FF  OAM shadow
$0300-$032F  enemy arrays
$0340-$0357  player bullet arrays
$0360-$0377  enemy bullet arrays
```

The project uses struct-of-arrays storage so enemy iteration can stay simple and indexed with X/Y.

## Rendering

- Background pattern table: `$0000`
- Sprite pattern table: `$1000`
- Native 8×8 OAM sprites; regular enemies are composed as 2×2 / 16×16 actors
- OAM shadow copied with `$4014` DMA from page `$02` during NMI
- Scroll is written during NMI
- Gameplay background scroll increments every other game frame
- Each stage uses a generated 1 KiB nametable

The stage nametable is repeated by the mirroring/scroll reset scheme. This avoids a streaming tile engine and keeps the NROM code compact.

## PPU-safe screen transitions

Long VRAM uploads are done with rendering and NMI disabled:

1. Wait for a frame boundary.
2. Disable NMI in `$2000`.
3. Disable rendering in `$2001`.
4. Upload 1 KiB nametable + 32-byte palette.
5. Reset scroll latch.
6. Re-enable NMI and rendering.

## Object budgets

Hard software limits:

- 6 active regular-enemy slots (arrays reserve 8 entries)
- 8 player bullets
- 8 enemy bullets
- 1 power-up
- 5 sprites for player including exhaust
- 4 sprites per regular 16×16 enemy
- 12 sprites for the 32×24 boss
- 6 score digit sprites plus compact HUD icons

This does not guarantee zero PPU sprite overflow, but it intentionally avoids modern bullet-count assumptions.

## Audio

APU channels:

- `$4000-$4003`: Pulse 1 melody
- `$4004-$4007`: Pulse 2 harmony / SFX steal
- `$4008-$400B`: Triangle bass
- `$400C-$400F`: Noise percussion and impact SFX

DMC is not used.

The v2 music engine advances through **128-step patterns**. Step speed is selected per song (4–7 video frames per step), so the title, stages, boss and victory music do not share one fixed tempo.

Pitch data uses a generated **48-note chromatic C2–B5 table** derived from the NTSC 2A03 clock. Pulse 1 and Pulse 2 get independent duty-cycle changes, and their constant-volume registers are reshaped every video frame to create short envelopes. Pulse 1 also receives a guarded ±1 timer modulation after the attack for subtle vibrato without resetting its high timer byte.

Noise percussion has four authored events (metallic hat, snare, low kick/tom and crash). Gameplay SFX may steal Pulse 2 or Noise; the music state keeps advancing and the channel returns on a later musical event.

All six songs use original note/event data. `tools/music_test.py` validates array lengths/ranges and `tools/render_audio_preview.py` can render a non-cycle-accurate WAV for quick auditioning.

## Asset pipeline

`tools/gen_assets.py` creates all visual ROM data from source definitions:

- 256-tile background pattern table
- 256-tile sprite pattern table
- 5×7 ASCII-like font and custom multi-tile title art
- player ship and animated exhaust
- 3 enemy archetypes × 3 stage-specific visual families × 2 animation frames
- stage-specific enemy bullets, animated power crystal and weapon-level player bolts
- six 16×16 explosion frames plus pulse/shield/reticle effect art
- modular boss parts and six extension-ready special enemies
- stage-specific rock, hull, vent, conduit, coil, relay and damage texture tiles
- title / stage / end nametables
- raw `assets/tiles.png` CHR contact sheet and assembled `assets/art-atlas.png`

`assets/chr.bin` is exactly 8 KiB.

## Assembler

`tools/asm6502.py` is intentionally not a general replacement for ca65. It supports the instructions and directives used by this project:

- `.org`
- `.byte`
- `.word`
- `.incbin`
- label expressions and low/high-byte operators
- standard zero-page/absolute/indexed/indirect addressing required here

Conditional branch mnemonics are encoded as:

```text
inverse-branch +3
JMP target
```

This makes every source-level branch distance-safe at the cost of a few bytes/cycles, acceptable within 32 KiB PRG.

## Tests

`tools/build.py` validates:

- PRG = 32 KiB
- CHR = 8 KiB
- valid NMI / RESET / IRQ vectors inside PRG
- iNES output construction

`tools/smoke_test.py` is a small non-cycle-accurate 6502 interpreter with stubbed NES I/O. It scripts Start, movement, shooting and one Pulse action, then checks that the game stays in valid states without hitting an unknown opcode, BRK, or broken stack/control flow.

It is complementary to, not a replacement for, testing on Mesen/FCEUX/Nestopia and real hardware.
