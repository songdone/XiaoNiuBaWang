# NESシューティング研究メモ

この資料は、VOID LANCERを「現代のゲームを8bit風にしたもの」ではなく、NES/Famicomの制約と1980年代STGの設計思想から組み立てるための調査メモです。

## 1. 研究対象から抽出した要素

### Star Soldier (Hudson Soft, 1986)

Star SoldierはFamicom向け縦スクロールSTGで、HudsonのCaravan競技を強く意識した作品として、敵の量・種類・スコア競争を重視していました。短時間でも「倒す → 次の隊列 → ボーナス」というリズムが明確で、画面上に大量の情報を出しつつプレイヤーの進行方向を迷わせません。

VOID LANCERでは次を抽出しました。

- 縦方向に常に前進する画面
- 隊列単位で敵を投入するテンポ
- 画面上部に常時スコアを表示
- 短いプレイ時間でもスコア更新が見える構造
- 敵やアイテムをシルエットで即判別できる低解像度デザイン

参考: https://shmups.wiki/library/Star_Soldier

### Zanac (Compile, 1986 / Famicom版)

Zanacで特に重要なのは、プレイヤーの行動に応じて敵の圧力が変化する考え方です。発射・パワーアップ・拠点破壊などが敵の量や難度に影響すると解説されています。

VOID LANCERではその思想だけを取り入れ、完全に独自の **Threat 0–7** を実装しました。

- 一定回数射撃するとThreat上昇
- 一定数撃破するとThreat上昇
- パワーアップ取得でThreat上昇
- 被弾するとThreat低下
- Threatが高いほど敵の再出現間隔が短くなる

つまり「強く・積極的に遊ぶほどゲームも攻めてくる」という構造です。Zanacの内部ロジックや数値を再現したものではありません。

参考: https://nesninja.com/game/nes/zanac

### Gradius / NES版周辺

Gradius系で重要なのは、敵編隊とパワーアップの関係が視覚的にわかりやすく、強化が単なるランダムドロップではなく「次の報酬を狙う行為」になっている点です。Power Capsuleを集めてPower Meterを進める仕組みは、プレイヤーに強化タイミングの選択を与えます。

VOID LANCERではPower Meter自体はコピーせず、次だけを取り入れました。

- 撃破を積み上げると一定周期でPowerアイテムが出る
- Powerは武器レベル0→1→2を上げる
- 強化は同時にThreatも上げるため、単純なご褒美だけではない

参考: https://gradius.fandom.com/wiki/Power_Meter
参考: https://gradius.fandom.com/wiki/Power_Capsule

### 1943: The Battle of Midway / NES

1943では、通常戦→より危険な区間→ボスというミッション進行、特殊攻撃・エネルギー・編隊撃破による報酬など、1ステージの中に複数の意思決定を持たせています。

VOID LANCERでは以下の形に変換しました。

- A=通常射撃、B=有限資源のPulse
- ステージごとに敵構成と背景を変える
- 最終ステージは通常ウェーブからボスへ移行
- ボムは敵弾消去＋雑魚排除＋ボスへの部分ダメージ

参考: https://gamefaqs.gamespot.com/nes/587059-1943-the-battle-of-midway/faqs/6816

## 2. NESハードウェアから決めた見た目

NES PPUは背景・スプライトともに8×8タイルを基本とし、1タイルは2bppです。背景とスプライトにはそれぞれ4つのパレットがあり、1オブジェクト/領域で使える色数は強く制限されます。

またOAMは64スプライトですが、1走査線に選ばれるスプライトは8個までです。このため現代的な弾幕STGのように何十発も同じ高さへ並べるのではなく、縦方向に分散しやすい敵配置と小さい弾を前提にしました。

参考: https://www.nesdev.org/wiki/PPU_programmer_reference
参考: https://www.nesdev.org/wiki/PPU_sprite_evaluation
参考: https://www.nesdev.org/wiki/PPU_palettes

## 3. 音楽設計

NES APUには2つのPulse、Triangle、Noise、DMCの計5チャンネルがあります。VOID LANCERはDMCを使わず、以下の4チャンネルだけで構成しています。

- Pulse 1: 主旋律
- Pulse 2: ハーモニー / 一時的にSEへ譲る
- Triangle: ベース
- Noise: ドラム風アクセント、ヒット、爆発、Pulse

曲は32ステップの短いパターンをループさせ、タイトル・通常ステージ・Core・Bossで配列を切り替えます。既存曲のメロディや音色データは使用していません。

参考: https://www.nesdev.org/wiki/APU
参考: https://www.nesdev.org/wiki/APU_basics

## 4. Mapperの選択

「実際に初期NESカートリッジとして成立しそう」という制約を優先し、Mapper 0 / NROM-256を選びました。

NROM-256は32 KiB PRG-ROM + 8 KiB CHR-ROMで、バンク切り替えやIRQを持ちません。その代わり構造が単純で、ホームブリューの最小構成として理解しやすいです。

参考: https://www.nesdev.org/wiki/NROM
参考: https://www.nesdev.org/wiki/Programming_NROM

## 5. コピーしなかったもの

以下は意図的に再利用していません。

- 商用ROMから吸い出したCHR
- 商用ゲームのロゴ・機体・敵キャラクター
- 商用ゲームのBGM/譜面/効果音
- ステージマップ
- ソースコードや逆アセンブル結果
- 固有名称

VOID LANCERのCHR、フォント、背景、機体、敵、ボス、楽曲シーケンス、ゲームロジックはこのリポジトリ用に新規作成しています。


## Audio research added for soundtrack v2

The soundtrack redesign studied **capabilities**, not commercial melodies. The NES 2A03 pulse registers expose four duty sequences plus volume/envelope controls, which makes timbre changes possible without extra channels. The project now uses this as arrangement vocabulary rather than holding one square-wave duty for an entire song.

FamiStudio/FamiTracker-style workflows also make heavy use of volume, pitch, arpeggio and duty-cycle envelopes. VOID LANCER implements a deliberately smaller custom subset directly in 6502: per-frame pulse volume shaping, per-section duty changes, small lead pitch motion and authored Noise percussion.

References:

- NESdev APU Pulse: https://www.nesdev.org/wiki/APU_Pulse
- NESdev APU Sweep: https://www.nesdev.org/wiki/APU_Sweep
- FamiStudio sound engine: https://famistudio.org/doc/soundengine/
- FamiStudio instruments/envelopes: https://famistudio.org/doc/instruments/

The melody, bass, harmony and drum event arrays in `src/main.asm` are original to VOID LANCER. No NSF, FTM, MIDI, DPCM sample, or note sequence was imported from a commercial title.
